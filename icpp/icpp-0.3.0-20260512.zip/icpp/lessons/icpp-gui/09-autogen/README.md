# 09 autogen で楽にする

## このレッスンで学ぶこと

`.autogen on` を使い、`.e` 後の再評価前に自動で `run_all` が走ることを確認します。

## 操作

```text
icpp[qtcling]> .autogen on
icpp[qtcling]> .status
icpp[qtcling]> .e widget.h
icpp[qtcling]> .e widget.cpp
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
```

## 期待される結果

`.e widget.cpp` のあとに `Autogen: run_all` が表示され、resource を使う widget が表示されます。
