# 11 失敗を直す

## このレッスンで学ぶこと

`.ui` の objectName と C++ 側の参照名がずれているとき、interpreter の診断と `.uiinfo` で原因を確認します。

## 操作

```text
icpp[qtcling]> .add widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .uiinfo form.ui
```

## 期待される結果

`widget.cpp` の評価で、`messageLabel` が `Ui::Form` に存在しないというエラーが表示されます。

`.uiinfo form.ui` では、実際の label の objectName が `titleLabel` であることを確認できます。

表示された診断で C++ 側の参照名を確認し、`.uiinfo` で `.ui` 側の objectName を確認します。

## 発展

`widget.cpp` は、存在しない objectName を参照しています。

```cpp
ui.messageLabel->setText("Fixed");
```

`form.ui` の中では label の objectName は `titleLabel` です。C++ 側を次のように直してください。

```cpp
ui.titleLabel->setText("Fixed");
```

修正後、もう一度 `.gen` を実行してください。`go()` で widget を作れることを確認できます。
