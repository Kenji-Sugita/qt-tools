# 08 resource を変更して反映する

## このレッスンで学ぶこと

resource の元ファイルを変更したら、`.gen` で `qrc_resources.cpp` を再生成する必要があることを学びます。

## 操作

```text
icpp[qtcling]> .e widget.h
icpp[qtcling]> .add widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto first = go();
icpp[qtcling]> .x first->show();
icpp[qtcling]> .e message.txt
# message.txt を Second message に変更して保存する
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto second = go();
icpp[qtcling]> .x second->show();
```

## 期待される結果

最初のウィンドウと、変更後のウィンドウで表示されるメッセージが変わります。

## ポイント

`message.txt` は resource の入力です。ファイルを変更しただけでは、既に生成済みの `qrc_resources.cpp` は変わりません。保存後に `.gen` を実行し、resource 生成物を更新します。
