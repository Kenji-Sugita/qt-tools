# 07 resource を使う

## このレッスンで学ぶこと

`.qrc` に入れた `message.txt` を、`Widget` class の label に表示します。

## 操作

```text
icpp[qtcling]> .qrc resources.qrc
# resources.qrc を確認して保存する
icpp[qtcling]> .e widget.h
icpp[qtcling]> .add widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

resource から読んだメッセージがウィンドウに表示されます。

## ポイント

`qrc_resources.cpp` は直接 `.add` せず、`widget.cpp` から include します。

`resources.qrc` は `rcc` の入力です。`qrc_resources.cpp` がまだない状態で `widget.cpp` を評価しないように、先に `.add widget.cpp` してから `.gen` します。

`.qrc` はエディタを開く操作です。resource file を確認したら保存して閉じ、icpp に戻って `.gen` を実行してください。
