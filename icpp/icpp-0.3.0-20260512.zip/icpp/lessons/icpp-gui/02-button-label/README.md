# 02 ヘッダーと実装を分ける

## このレッスンで学ぶこと

`widget.h` に `Widget` class の宣言を書き、`widget.cpp` に constructor の実装を書きます。

## 操作

```text
icpp[qtcling]> .e widget.h
icpp[qtcling]> .e widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

ラベルとボタンを持つウィンドウが表示されます。

## ポイント

まだクリック処理は書きません。まずはヘッダーと実装を分ける基本形に慣れます。
