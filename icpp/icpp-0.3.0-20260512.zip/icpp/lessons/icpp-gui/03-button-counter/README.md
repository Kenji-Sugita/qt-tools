# 03 lambda connect でボタンとラベルを動かす

## このレッスンで学ぶこと

`Widget` class に `QLabel *label` と `int count` を持たせ、lambda connect でボタン操作を処理します。

## 操作

```text
icpp[qtcling]> .e widget.h
icpp[qtcling]> .e widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

ボタンを押すたびに、ラベルのカウントが増えます。
