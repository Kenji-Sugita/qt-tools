# 05 Q_OBJECT と slot を使う

## このレッスンで学ぶこと

`Q_OBJECT` を持つ class をヘッダーに分け、slot を使います。`.gen` で `moc_widget.cpp` を生成します。

## 操作

```text
icpp[qtcling]> .e widget.h
icpp[qtcling]> .e widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

ボタンを押すたびに、slot が呼ばれてカウントが増えます。

## ポイント

`moc_widget.cpp` がまだない場合、icpp は空の placeholder で include エラーを避けることがあります。ただし本物ではないので、必ず `.gen` で生成します。
