# 04 スライダーを class の状態に接続する

## このレッスンで学ぶこと

`Widget` class に `QSlider` と `QLabel` を持たせ、private method で表示を更新します。

## 操作

```text
icpp[qtcling]> .e widget.h
icpp[qtcling]> .e widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

スライダーを動かすと、ラベルの数値が変わります。
