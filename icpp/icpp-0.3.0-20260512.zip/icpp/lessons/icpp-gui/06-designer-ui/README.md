# 06 Designer UI を使う

## このレッスンで学ぶこと

`.ui` から `ui_form.h` を生成し、`Widget` class に組み込んで動かします。

## 操作

```text
icpp[qtcling]> .designer form.ui
# Qt Designer で form.ui を保存する
icpp[qtcling]> .e widget.h
icpp[qtcling]> .add widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

UI ファイルで配置した button と slider が表示されます。button を押すと label が変わり、slider を動かすと数値が変わります。

## ポイント

`form.ui` は `uic` の入力です。`ui_form.h` がまだない状態で `widget.cpp` を評価しないように、先に `.add widget.cpp` してから `.gen` します。

`.designer` は Qt Designer を開くとすぐ icpp に戻ります。UI を変更したら、Qt Designer 側で保存してから `.gen` を実行してください。
