# 01 ヘッダーのみで小さな Widget を作る

## このレッスンで学ぶこと

`widget.h` だけで小さな `Widget` class を定義し、`widget.cpp` の `go()` から表示します。

## 操作

```text
icpp[qtcling]> .e widget.h
icpp[qtcling]> .e widget.cpp
icpp[qtcling]> .gen
icpp[qtcling]> .defs
icpp[qtcling]> .x static auto w = go();
icpp[qtcling]> .x w->show();
icpp[qtcling]> .x w->raise();
```

## 期待される結果

タイトル付きの小さなウィンドウが表示されます。

## ポイント

最初は constructor をヘッダー内に inline で書きます。小さい class ならこの形でも試しやすく、icpp での最初の練習に向いています。

## よくある失敗

- `.x static auto w = go();` の前に `.gen` を忘れる
- `go()` の戻り値を保存せずに `go()->show();` だけ実行し、後で操作しづらくなる
