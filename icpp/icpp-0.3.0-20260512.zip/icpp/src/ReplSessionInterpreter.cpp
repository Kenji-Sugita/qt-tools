#include "icpp/ReplSessionImpl.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QList>
#include <QLibraryInfo>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QTemporaryFile>
#include <QTextStream>
#include <QXmlStreamReader>

#if defined(HAVE_READLINE)
#include <readline/history.h>
#endif

#include <algorithm>
#include <cstdlib>
#include <optional>
#include <utility>

namespace icpp {

void ReplSessionImpl::runVisibleSourceCode()
{
    if (!prepareAutogenIfEnabled()) {
        return;
    }
    runVisibleSourceCodeWithoutAutogen();
}

void ReplSessionImpl::runVisibleSourceCodeWithoutAutogen()
{
    const QString sourceCodeToEvaluate = visibleSourceCode();
    if (registeredSourceFilePaths.isEmpty() && sourceCodeToEvaluate.isEmpty()) {
        reportError(trMessage(QStringLiteral("実行するファイルまたは編集バッファがありません。"),
                              QStringLiteral("No files or edit buffer to run.")));
        return;
    }

    if (interpreter.restart()) {
        for (const QString& pragma : includePathPragmas) {
            interpreter.sendSource(pragma);
        }
        for (const QString& filePath : registeredSourceFilePaths) {
            const std::optional<QString> sourceCode = readTextFile(filePath);
            if (!sourceCode.has_value()) {
                return;
            }
            ensureMocIncludePlaceholders(*sourceCode, QFileInfo(filePath).absoluteDir());
            interpreter.sendSource(*sourceCode);
        }
        if (!sourceCodeToEvaluate.isEmpty()) {
            ensureMocIncludePlaceholders(sourceCodeToEvaluate, QDir::current());
            interpreter.sendSource(sourceCodeToEvaluate);
        }
    }
}

void ReplSessionImpl::restartInterpreter()
{
    if (interpreter.restart()) {
        standardOutput << trMessage(QStringLiteral("interpreter を再起動しました。"),
                                    QStringLiteral("Interpreter restarted."))
                       << Qt::endl;
    }
}

void ReplSessionImpl::resetSession()
{
    if (visibleBufferHasUnsavedChanges()
        && !confirmYesNo(trMessage(
            QStringLiteral("警告: 未保存の編集バッファがあります。セッションをリセットしますか? [Y/N] "),
            QStringLiteral("Warning: edit buffer has unsaved changes. Reset the session? [Y/N] ")))) {
        return;
    }

    if (interpreter.restart()) {
        committedSourceCode.clear();
        registeredSourceFilePaths.clear();
        includePathPragmas.clear();
        touchedSourceFilePaths.clear();
        rememberedVisibleBufferFilePath.clear();
        lastSavedVisibleSourceCode.clear();
        standardOutput << trMessage(QStringLiteral("セッションをリセットしました。"),
                                    QStringLiteral("Session reset."))
                       << Qt::endl;
    }
}

void ReplSessionImpl::ensureMocIncludePlaceholders(const QString& sourceCode, const QDir& baseDirectory)
{
    for (const QString& filePath : missingMocIncludes(sourceCode, baseDirectory)) {
        QFileInfo fileInfo(filePath);
        if (!fileInfo.absoluteDir().exists()) {
            continue;
        }
        if (writeTextFile(filePath, QString())) {
            standardOutput << trMessage(QStringLiteral("placeholder を作成しました: %1"),
                                        QStringLiteral("Created placeholder: %1"))
                                  .arg(filePath)
                           << Qt::endl;
        }
    }
}

void ReplSessionImpl::loadLibrary(const QString& path, const QString& historyEntry)
{
    if (path.isEmpty()) {
        reportError(trMessage(QStringLiteral(".loadlib にはライブラリパスが必要です。"),
                              QStringLiteral(".loadlib requires a library path.")));
        return;
    }

    const QString pragma = QStringLiteral("#pragma cling load(\"%1\")").arg(quoteForPragma(path));
    appendSource(pragma);
    interpreter.sendSource(pragma);
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::includeHeader(const QString& header, const QString& historyEntry)
{
    if (header.isEmpty()) {
        reportError(trMessage(QStringLiteral(".include にはヘッダ名が必要です。"),
                              QStringLiteral(".include requires a header name.")));
        return;
    }

    QString includeDirective;
    if (header.startsWith(QLatin1Char('<')) || header.startsWith(QLatin1Char('"'))) {
        includeDirective = QStringLiteral("#include %1").arg(header);
    } else {
        includeDirective = QStringLiteral("#include <%1>").arg(header);
    }

    appendSource(includeDirective);
    interpreter.sendSource(includeDirective);
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::addIncludePath(const QString& path, const QString& historyEntry)
{
    if (path.isEmpty()) {
        reportError(trMessage(QStringLiteral(".i には include path が必要です。"),
                              QStringLiteral(".i requires an include path.")));
        return;
    }

    const QString pragma = QStringLiteral("#pragma cling add_include_path(\"%1\")")
                               .arg(quoteForPragma(path));
    if (!includePathPragmas.contains(pragma)) {
        includePathPragmas.append(pragma);
    }
    interpreter.sendSource(pragma);
    standardOutput << trMessage(QStringLiteral("include path を追加しました: %1"),
                                QStringLiteral("Added include path: %1"))
                          .arg(path)
                   << Qt::endl;
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::sendPragma(const QString& argument, const QString& historyEntry)
{
    if (argument.isEmpty()) {
        reportError(trMessage(QStringLiteral(".pragma には引数が必要です。"),
                              QStringLiteral(".pragma requires an argument.")));
        return;
    }

    const QString pragma = QStringLiteral("#pragma cling %1").arg(argument);
    appendSource(pragma);
    interpreter.sendSource(pragma);
    addHistoryEntry(historyEntry);
}

bool ReplSessionImpl::executeExternalCommand(const QString& command)
{
    QProcess process;
    process.setProcessChannelMode(QProcess::ForwardedChannels);

#if defined(Q_OS_WIN)
    const QString shellProgram = QStringLiteral("cmd.exe");
    const QStringList shellArguments{QStringLiteral("/C"), command};
#else
    const QString shellProgram = QStringLiteral("/bin/sh");
    const QStringList shellArguments{QStringLiteral("-lc"), command};
#endif

    process.start(shellProgram, shellArguments);
    if (!process.waitForStarted()) {
        reportError(trMessage(QStringLiteral("外部コマンドを起動できません: %1"),
                              QStringLiteral("Cannot start external command: %1"))
                        .arg(command));
        return false;
    }

    process.waitForFinished(-1);

    if (process.exitStatus() != QProcess::NormalExit) {
        reportError(trMessage(QStringLiteral("外部コマンドがクラッシュしました: %1"),
                              QStringLiteral("External command crashed: %1"))
                        .arg(command));
        return false;
    }

    if (process.exitCode() != 0) {
        reportError(
            trMessage(QStringLiteral("外部コマンドがステータス %1 で終了しました: %2"),
                      QStringLiteral("External command exited with status %1: %2"))
                .arg(process.exitCode())
                .arg(command));
        return false;
    }

    return true;
}

void ReplSessionImpl::runExternalCommand(const QString& command, const QString& historyEntry)
{
    if (command.isEmpty()) {
        reportError(trMessage(QStringLiteral(".! にはコマンドが必要です。"),
                              QStringLiteral(".! requires a command.")));
        return;
    }

    executeExternalCommand(command);
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::generateQtFilesAndRun(const QString& historyEntry)
{
    if (visibleBufferHasUnsavedChanges() && !rememberedVisibleBufferFilePath.isEmpty()) {
        standardError << trMessage(
                             QStringLiteral("警告: 編集バッファに未保存の変更があります。.gen の前に .save することを推奨します。"),
                             QStringLiteral("Warning: edit buffer has unsaved changes. Run .save before .gen if generated files depend on it."))
                      << Qt::endl;
    }

    if (!executeExternalCommand(QStringLiteral("run_all"))) {
        addHistoryEntry(historyEntry);
        return;
    }

    runVisibleSourceCodeWithoutAutogen();
    addHistoryEntry(historyEntry);
}

bool ReplSessionImpl::prepareAutogenIfEnabled()
{
    if (!autogenEnabled || !qtGeneratedFilesMayBeNeeded()) {
        return true;
    }

    if (visibleBufferHasUnsavedChanges()) {
        if (rememberedVisibleBufferFilePath.isEmpty()) {
            standardError << trMessage(
                                 QStringLiteral("警告: autogen には保存済みファイルが必要です。.save <file> を実行してください。"),
                                 QStringLiteral("Warning: autogen needs a saved file. Use .save <file> first."))
                          << Qt::endl;
        } else if (confirmYesNo(trMessage(
                       QStringLiteral("警告: autogen の前に編集バッファを %1 に保存しますか? [Y/N] "),
                       QStringLiteral("Warning: save edit buffer to %1 before autogen? [Y/N] "))
                       .arg(rememberedVisibleBufferFilePath))) {
            if (!writeTextFile(rememberedVisibleBufferFilePath, visibleSourceCode())) {
                return false;
            }
            lastSavedVisibleSourceCode = visibleSourceCode();
            rememberTouchedSourceFile(rememberedVisibleBufferFilePath);
            standardOutput << trMessage(QStringLiteral("保存しました: %1"),
                                        QStringLiteral("Saved: %1"))
                                  .arg(QFileInfo(rememberedVisibleBufferFilePath).fileName())
                           << Qt::endl;
        } else {
            return true;
        }
    }

    standardOutput << trMessage(QStringLiteral("autogen: run_all"),
                                QStringLiteral("Autogen: run_all"))
                   << Qt::endl;
    return executeExternalCommand(QStringLiteral("run_all"));
}

bool ReplSessionImpl::qtGeneratedFilesMayBeNeeded() const
{
    const QString sourceCode = visibleSourceCode();
    static const QRegularExpression mocIncludePattern(
        QStringLiteral(R"re(#\s*include\s*[<"][^>"]+\.moc[>"])re"));
    if (sourceCode.contains(QStringLiteral("Q_" "OBJECT"))
        || mocIncludePattern.match(sourceCode).hasMatch()) {
        return true;
    }

    for (const QString& filePath : registeredSourceFilePaths) {
        const QString suffix = QFileInfo(filePath).suffix().toLower();
        if (suffix == QStringLiteral("ui") || suffix == QStringLiteral("qrc")) {
            return true;
        }
        const std::optional<QString> sourceCode = readTextFile(filePath);
        if (sourceCode.has_value()
            && (sourceCode->contains(QStringLiteral("Q_" "OBJECT"))
                || mocIncludePattern.match(*sourceCode).hasMatch())) {
            return true;
        }
    }

    const QDir currentDirectory = QDir::current();
    return !currentDirectory.entryList(QStringList() << QStringLiteral("*.ui")
                                                     << QStringLiteral("*.qrc"),
                                       QDir::Files)
                .isEmpty();
}

void ReplSessionImpl::warnIfQtGeneratedFilesMayBeStale() const
{
    if (qtGeneratedFilesMayBeNeeded()) {
        standardError
            << trMessage(QStringLiteral("警告: Qt 生成物が必要な可能性があります。.gen で moc/uic/rcc を再生成して再起動してください。"),
                         QStringLiteral("Warning: Qt generated files may be needed. Run .gen to regenerate moc/uic/rcc and restart."))
            << Qt::endl;
    }
}

} // namespace icpp
