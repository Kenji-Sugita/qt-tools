#include "icpp/ReplSessionImpl.h"

#include <QDir>
#include <QFileInfo>
#include <QProcess>
#include <QRegularExpression>
#include <QTextStream>

#include <optional>

namespace icpp {

namespace {

struct TemplateFile {
    QString path;
    QString sourceCode;
};

QString xmlEscaped(QString text)
{
    text.replace(QLatin1Char('&'), QStringLiteral("&amp;"));
    text.replace(QLatin1Char('<'), QStringLiteral("&lt;"));
    text.replace(QLatin1Char('>'), QStringLiteral("&gt;"));
    text.replace(QLatin1Char('"'), QStringLiteral("&quot;"));
    text.replace(QLatin1Char('\''), QStringLiteral("&apos;"));
    return text;
}

QString sanitizedFileStem(QString text)
{
    text = text.trimmed();
    text.replace(QRegularExpression(QStringLiteral("[^A-Za-z0-9_]+")), QStringLiteral("_"));
    text.replace(QRegularExpression(QStringLiteral("_+")), QStringLiteral("_"));
    text.remove(QRegularExpression(QStringLiteral("^_+|_+$")));
    if (text.isEmpty()) {
        return QStringLiteral("widget");
    }
    return text.toLower();
}

QString classNameFromFileStem(const QString& fileStem)
{
    QString result;
    bool capitalizeNext = true;
    for (const QChar character : fileStem) {
        if (!character.isLetterOrNumber()) {
            capitalizeNext = true;
            continue;
        }
        if (result.isEmpty() && character.isDigit()) {
            result.append(QLatin1Char('_'));
        }
        const QString text(character);
        result.append(capitalizeNext ? text.toUpper() : text);
        capitalizeNext = false;
    }
    return result.isEmpty() ? QStringLiteral("Widget") : result;
}

QFileInfo templateBaseInfo(const QString& base)
{
    QFileInfo rawInfo(base);
    const QString parentPath = rawInfo.path() == QStringLiteral(".") ? QString() : rawInfo.path();
    const QString stem = sanitizedFileStem(rawInfo.completeBaseName());
    const QString filePath = parentPath.isEmpty() ? stem : QDir(parentPath).filePath(stem);
    return QFileInfo(filePath);
}

QString widgetHeaderSource(const QString& className)
{
    return QStringLiteral(R"(#pragma once

#include <QWidget>

class %1 : public QWidget {
public:
    explicit %1(QWidget *parent = nullptr);
};
)")
        .arg(className);
}

QString qobjectHeaderSource(const QString& className)
{
    return QStringLiteral(R"(#pragma once

#include <QWidget>

class %1 : public QWidget {
    %2

public:
    explicit %1(QWidget *parent = nullptr);
};
)")
        .arg(className, QStringLiteral("Q_" "OBJECT"));
}

QString widgetCppSource(const QString& stem, const QString& className)
{
    return QStringLiteral(R"(#include "%1.h"

#include <QLabel>
#include <QVBoxLayout>

%2::%2(QWidget *parent) : QWidget(parent) {
    auto *layout = new QVBoxLayout(this);
    auto *label = new QLabel("Hello icpp", this);
    layout->addWidget(label);
    setWindowTitle("%2");
    resize(260, 120);
}

%2 *go() {
    return new %2;
}
)")
        .arg(stem, className);
}

QString qobjectCppSource(const QString& stem, const QString& className)
{
    return QStringLiteral(R"(#include "%1.h"

#include <QLabel>
#include <QVBoxLayout>

%2::%2(QWidget *parent) : QWidget(parent) {
    auto *layout = new QVBoxLayout(this);
    auto *label = new QLabel("Hello icpp", this);
    layout->addWidget(label);
    setWindowTitle("%2");
    resize(260, 120);
}

%2 *go() {
    return new %2;
}

#include "%3"
)")
        .arg(stem, className, QStringLiteral("moc_%1.cpp").arg(stem));
}

QString uiHeaderSource(const QString& className)
{
    return QStringLiteral(R"(#pragma once

#include <QWidget>

namespace Ui {
class Form;
}

class %1 : public QWidget {
public:
    explicit %1(QWidget *parent = nullptr);
};
)")
        .arg(className);
}

QString uiCppSource(const QString& stem, const QString& className)
{
    return QStringLiteral(R"(#include "%1.h"

#include "ui_%1.h"

%2::%2(QWidget *parent) : QWidget(parent) {
    Ui::Form ui;
    ui.setupUi(this);
    setWindowTitle("%2");
}

%2 *go() {
    return new %2;
}
)")
        .arg(stem, className);
}

QString uiFileSource(const QString& className)
{
    return QStringLiteral(R"(<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>Form</class>
 <widget class="QWidget" name="Form">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>360</width>
    <height>180</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>%1</string>
  </property>
  <layout class="QVBoxLayout" name="verticalLayout">
   <item>
    <widget class="QLabel" name="titleLabel">
     <property name="text">
      <string>Hello icpp</string>
     </property>
    </widget>
   </item>
  </layout>
 </widget>
 <resources/>
 <connections/>
</ui>
)")
        .arg(xmlEscaped(className));
}

QString qrcCppSource(const QString& stem, const QString& className)
{
    return QStringLiteral(R"(#include "%1.h"

#include "qrc_%1.cpp"

#include <QFile>
#include <QLabel>
#include <QVBoxLayout>

%2::%2(QWidget *parent) : QWidget(parent) {
    auto *layout = new QVBoxLayout(this);
    auto *label = new QLabel(this);
    QFile file(":/message.txt");
    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        label->setText(QString::fromUtf8(file.readAll()).trimmed());
    } else {
        label->setText("message.txt not found");
    }
    layout->addWidget(label);
    setWindowTitle("%2");
    resize(260, 120);
}

%2 *go() {
    return new %2;
}
)")
        .arg(stem, className);
}

QString qrcFileSource()
{
    return QStringLiteral(R"(<RCC>
  <qresource prefix="/">
    <file>message.txt</file>
  </qresource>
</RCC>
)");
}

QList<TemplateFile> filesForTemplate(const QString& kind, const QFileInfo& baseInfo)
{
    const QString directoryPath = baseInfo.path() == QStringLiteral(".") ? QString() : baseInfo.path();
    const QString stem = baseInfo.fileName();
    const QString className = classNameFromFileStem(stem);
    auto pathFor = [&](const QString& fileName) {
        return directoryPath.isEmpty() ? fileName : QDir(directoryPath).filePath(fileName);
    };

    if (kind == QStringLiteral("widget")) {
        return {{pathFor(stem + QStringLiteral(".h")), widgetHeaderSource(className)},
                {pathFor(stem + QStringLiteral(".cpp")), widgetCppSource(stem, className)}};
    }
    if (kind == QStringLiteral("qobject")) {
        return {{pathFor(stem + QStringLiteral(".h")), qobjectHeaderSource(className)},
                {pathFor(stem + QStringLiteral(".cpp")), qobjectCppSource(stem, className)}};
    }
    if (kind == QStringLiteral("ui")) {
        return {{pathFor(stem + QStringLiteral(".h")), uiHeaderSource(className)},
                {pathFor(stem + QStringLiteral(".cpp")), uiCppSource(stem, className)},
                {pathFor(stem + QStringLiteral(".ui")), uiFileSource(className)}};
    }
    if (kind == QStringLiteral("qrc")) {
        return {{pathFor(stem + QStringLiteral(".h")), widgetHeaderSource(className)},
                {pathFor(stem + QStringLiteral(".cpp")), qrcCppSource(stem, className)},
                {pathFor(stem + QStringLiteral(".qrc")), qrcFileSource()},
                {pathFor(QStringLiteral("message.txt")), QStringLiteral("Hello icpp\n")}};
    }
    return {};
}

} // namespace

void ReplSessionImpl::showTemplateHelp(const QString& historyEntry)
{
    standardOutput << trMessage(
        QStringLiteral(R"(.template <kind> [base]

kind:
  widget    最小 QWidget クラスを作成します
  qobject   Q_%1OBJECT と moc include を含む QWidget クラスを作成します
  ui        .ui と ui_<base>.h を使う QWidget クラスを作成します
  qrc       .qrc と message.txt を使う QWidget クラスを作成します

base:
  生成ファイル名と class 名の元になる名前です。
  省略すると対話端末では入力を促します。
  空入力、または非対話実行では widget を使います。

例:
  .template widget counter
  .template qobject harness
  .template ui settings
  .template qrc message

既存ファイルは上書きしません。作成前にファイル一覧を表示して確認します。)"),
        QStringLiteral(R"(.template <kind> [base]

kind:
  widget    Create a minimal QWidget class
  qobject   Create a QWidget class with Q_%1OBJECT and moc include
  ui        Create a QWidget class using .ui and ui_<base>.h
  qrc       Create a QWidget class using .qrc and message.txt

base:
  Base name for generated files and the class name.
  If omitted in an interactive terminal, icpp asks for it.
  Empty input, or non-interactive use, defaults to widget.

examples:
  .template widget counter
  .template qobject harness
  .template ui settings
  .template qrc message

Existing files are never overwritten. icpp shows the file list before creation.)"))
                   .arg(QString())
                   << Qt::endl;
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::handleTemplateCommand(const QString& argument, const QString& historyEntry)
{
    QStringList parts = QProcess::splitCommand(argument);
    if (parts.isEmpty() || parts.first() == QStringLiteral("-h")
        || parts.first() == QStringLiteral("--help") || parts.first() == QStringLiteral("help")) {
        showTemplateHelp(historyEntry);
        return;
    }

    const QString kind = parts.takeFirst().toLower();
    if (kind != QStringLiteral("widget") && kind != QStringLiteral("qobject")
        && kind != QStringLiteral("ui") && kind != QStringLiteral("qrc")) {
        reportError(trMessage(QStringLiteral("不明な template kind です: %1。詳しくは .template -h"),
                              QStringLiteral("Unknown template kind: %1. Use .template -h for details."))
                        .arg(kind));
        return;
    }

    QString base = parts.join(QLatin1Char(' ')).trimmed();
    if (base.isEmpty() && shouldShowPrompt()) {
        standardOutput << trMessage(QStringLiteral("ベース名を入力してください [widget]: "),
                                    QStringLiteral("Base name [widget]: "))
                       << Qt::flush;
        const std::optional<QString> answer = readConsoleLine(QString());
        if (!answer.has_value()) {
            standardOutput << Qt::endl;
            return;
        }
        base = answer->trimmed();
    }
    if (base.isEmpty()) {
        base = QStringLiteral("widget");
    }

    const QFileInfo baseInfo = templateBaseInfo(base);
    if (!baseInfo.absoluteDir().exists()) {
        reportError(trMessage(QStringLiteral("%1: ディレクトリが見つかりません。"),
                              QStringLiteral("%1: Directory not found."))
                        .arg(baseInfo.absoluteDir().absolutePath()));
        return;
    }

    const QList<TemplateFile> templateFiles = filesForTemplate(kind, baseInfo);
    for (const TemplateFile& file : templateFiles) {
        const QFileInfo fileInfo(file.path);
        if (fileInfo.exists()) {
            reportError(trMessage(QStringLiteral("既存ファイルがあるため作成しません: %1"),
                                  QStringLiteral("File already exists; not creating templates: %1"))
                            .arg(fileInfo.filePath()));
            return;
        }
    }

    const QString className = classNameFromFileStem(baseInfo.fileName());
    standardOutput << trMessage(QStringLiteral("作成するファイル:"),
                                QStringLiteral("Files to create:"))
                   << Qt::endl;
    for (const TemplateFile& file : templateFiles) {
        standardOutput << QStringLiteral("  %1").arg(file.path) << Qt::endl;
    }
    standardOutput << trMessage(QStringLiteral("class: %1"), QStringLiteral("class: %1"))
                          .arg(className)
                   << Qt::endl;

    if (!confirmYesNo(trMessage(QStringLiteral("続けますか? [Y/N] "),
                                QStringLiteral("Continue? [Y/N] ")))) {
        addHistoryEntry(historyEntry);
        return;
    }

    for (const TemplateFile& file : templateFiles) {
        if (!writeTextFile(file.path, file.sourceCode)) {
            return;
        }
        standardOutput << trMessage(QStringLiteral("作成しました: %1"),
                                    QStringLiteral("Created: %1"))
                              .arg(file.path)
                       << Qt::endl;
    }

    standardOutput << trMessage(QStringLiteral("次の操作:"), QStringLiteral("Next steps:"))
                   << Qt::endl;
    standardOutput << QStringLiteral("  .add %1").arg(baseInfo.filePath() + QStringLiteral(".cpp"))
                   << Qt::endl;
    if (kind == QStringLiteral("widget")) {
        standardOutput << QStringLiteral("  .r") << Qt::endl;
    } else {
        standardOutput << QStringLiteral("  .gen") << Qt::endl;
    }
    standardOutput << QStringLiteral("  .x static auto w = go();") << Qt::endl;
    standardOutput << QStringLiteral("  .x w->show();") << Qt::endl;
    addHistoryEntry(historyEntry);
}

} // namespace icpp
