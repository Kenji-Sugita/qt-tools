#include "icpp/ReplSessionImpl.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QList>
#include <QLibraryInfo>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QTemporaryFile>
#include <QTextStream>
#include <QXmlStreamReader>

#if defined(HAVE_READLINE)
#include <readline/history.h>
#endif

#include <algorithm>
#include <cstdlib>
#include <optional>
#include <utility>

namespace icpp {

namespace {

QString xmlEscaped(QString text)
{
    text.replace(QLatin1Char('&'), QStringLiteral("&amp;"));
    text.replace(QLatin1Char('<'), QStringLiteral("&lt;"));
    text.replace(QLatin1Char('>'), QStringLiteral("&gt;"));
    text.replace(QLatin1Char('"'), QStringLiteral("&quot;"));
    text.replace(QLatin1Char('\''), QStringLiteral("&apos;"));
    return text;
}

QString uiClassNameFromFileName(const QFileInfo& fileInfo)
{
    const QString baseName = fileInfo.completeBaseName();
    QString className;
    bool capitalizeNext = true;
    for (const QChar character : baseName) {
        if (character.isLetterOrNumber()) {
            QString text(character);
            if (className.isEmpty() && character.isDigit()) {
                className.append(QLatin1Char('_'));
            }
            className.append(capitalizeNext ? text.toUpper() : text);
            capitalizeNext = false;
        } else {
            capitalizeNext = true;
        }
    }

    if (className.isEmpty()) {
        return QStringLiteral("Form");
    }
    return className;
}

QString defaultUiFileSource(const QFileInfo& fileInfo)
{
    const QString className = uiClassNameFromFileName(fileInfo);
    const QString title = fileInfo.completeBaseName().isEmpty() ? QStringLiteral("Form") : fileInfo.completeBaseName();
    return QStringLiteral(R"(<?xml version="1.0" encoding="UTF-8"?>
<ui version="4.0">
 <class>%1</class>
 <widget class="QWidget" name="%1">
  <property name="geometry">
   <rect>
    <x>0</x>
    <y>0</y>
    <width>400</width>
    <height>300</height>
   </rect>
  </property>
  <property name="windowTitle">
   <string>%2</string>
  </property>
 </widget>
 <resources/>
 <connections/>
</ui>
)")
        .arg(xmlEscaped(className), xmlEscaped(title));
}

} // namespace

void ReplSessionImpl::openDesigner(const QString& filePathArgument, const QString& historyEntry)
{
    const QString filePath = filePathArgument.trimmed();
    if (filePath.isEmpty()) {
        reportError(trMessage(QStringLiteral(".designer には .ui ファイルパスが必要です。"),
                              QStringLiteral(".designer requires a .ui file path.")));
        return;
    }

    const QFileInfo fileInfo(filePath);
    if (fileInfo.suffix().toLower() != QStringLiteral("ui")) {
        reportError(trMessage(QStringLiteral("%1: .ui ファイルではありません。"),
                              QStringLiteral("%1: Not a .ui file."))
                        .arg(filePath));
        return;
    }
    if (fileInfo.exists() && !fileInfo.isFile()) {
        reportError(trMessage(QStringLiteral("%1: 通常ファイルではありません。"),
                              QStringLiteral("%1: Not a regular file."))
                        .arg(filePath));
        return;
    }
    if (!fileInfo.exists()) {
        const QDir parentDirectory = fileInfo.absoluteDir();
        if (!parentDirectory.exists()) {
            reportError(trMessage(QStringLiteral("%1: 親ディレクトリが見つかりません。"),
                                  QStringLiteral("%1: Parent directory not found."))
                            .arg(filePath));
            return;
        }
        if (!writeTextFile(fileInfo.absoluteFilePath(), defaultUiFileSource(fileInfo))) {
            return;
        }
        standardOutput << trMessage(QStringLiteral(".ui ファイルを作成しました: %1"),
                                    QStringLiteral("Created .ui file: %1"))
                              .arg(fileInfo.fileName())
                       << Qt::endl;
    }

    const QString absoluteFilePath = fileInfo.absoluteFilePath();
    if (!runDesignerForFile(absoluteFilePath)) {
        return;
    }

    rememberTouchedSourceFile(absoluteFilePath);
    standardOutput << trMessage(QStringLiteral("Designer で開きました: %1"),
                                QStringLiteral("Opened with Designer: %1"))
                          .arg(fileInfo.fileName())
                   << Qt::endl;
    standardOutput << trMessage(QStringLiteral("Designer で保存した後、.gen で生成物を更新してください。"),
                                QStringLiteral("After saving in Designer, run .gen to update generated files."))
                   << Qt::endl;
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::openLinguist(const QString& filePathArgument, const QString& historyEntry)
{
    const QString filePath = filePathArgument.trimmed();
    if (filePath.isEmpty()) {
        reportError(trMessage(QStringLiteral(".linguist には .ts ファイルパスが必要です。"),
                              QStringLiteral(".linguist requires a .ts file path.")));
        return;
    }

    const QFileInfo fileInfo(filePath);
    if (!fileInfo.exists() || !fileInfo.isFile()) {
        reportError(trMessage(QStringLiteral("%1: .ts ファイルが見つかりません。"),
                              QStringLiteral("%1: .ts file not found."))
                        .arg(filePath));
        return;
    }
    if (fileInfo.suffix().toLower() != QStringLiteral("ts")) {
        reportError(trMessage(QStringLiteral("%1: .ts ファイルではありません。"),
                              QStringLiteral("%1: Not a .ts file."))
                        .arg(filePath));
        return;
    }

    const QString absoluteFilePath = fileInfo.absoluteFilePath();
    if (!runLinguistForFile(absoluteFilePath)) {
        return;
    }

    rememberTouchedSourceFile(absoluteFilePath);
    standardOutput << trMessage(QStringLiteral("Linguist で開きました: %1"),
                                QStringLiteral("Opened with Linguist: %1"))
                          .arg(fileInfo.fileName())
                   << Qt::endl;
    standardOutput << trMessage(QStringLiteral("Linguist で保存した後、.! lrelease %1 で .qm を更新してください。"),
                                QStringLiteral("After saving in Linguist, run .! lrelease %1 to update the .qm file."))
                          .arg(filePath)
                   << Qt::endl;
    addHistoryEntry(historyEntry);
}

void ReplSessionImpl::openQrc(const QString& argument, const QString& historyEntry)
{
    QStringList parts = QProcess::splitCommand(argument);
    if (parts.isEmpty()) {
        reportError(trMessage(QStringLiteral(".qrc には .qrc ファイルパスが必要です。"),
                              QStringLiteral(".qrc requires a .qrc file path.")));
        return;
    }

    QString mode = QStringLiteral("text");
    if (parts.first() == QStringLiteral("text") || parts.first() == QStringLiteral("editor")
        || parts.first() == QStringLiteral("creator") || parts.first() == QStringLiteral("qtcreator")) {
        mode = parts.takeFirst();
        if (mode == QStringLiteral("editor")) {
            mode = QStringLiteral("text");
        }
        if (mode == QStringLiteral("qtcreator")) {
            mode = QStringLiteral("creator");
        }
    }

    const QString filePath = parts.join(QLatin1Char(' '));
    if (mode == QStringLiteral("creator")) {
        openQrcWithQtCreator(filePath, historyEntry);
        return;
    }

    openQrcWithTextEditor(filePath, historyEntry);
}

void ReplSessionImpl::openQrcWithTextEditor(const QString& filePathArgument, const QString& historyEntry)
{
    const QFileInfo fileInfo = validateQrcFilePath(filePathArgument, QStringLiteral(".qrc"));
    if (!fileInfo.exists()) {
        return;
    }

    const QString absoluteFilePath = fileInfo.absoluteFilePath();
    if (!runEditorForFile(absoluteFilePath)) {
        return;
    }

    rememberTouchedSourceFile(absoluteFilePath);
    standardOutput << trMessage(QStringLiteral("テキストエディタで編集しました: %1"),
                                QStringLiteral("Edited with text editor: %1"))
                          .arg(fileInfo.fileName())
                   << Qt::endl;
    finishQrcEdit(historyEntry);
}

void ReplSessionImpl::openQrcWithQtCreator(const QString& filePathArgument, const QString& historyEntry)
{
    const QFileInfo fileInfo = validateQrcFilePath(filePathArgument, QStringLiteral(".qtc"));
    if (!fileInfo.exists()) {
        return;
    }

    const QString absoluteFilePath = fileInfo.absoluteFilePath();
    if (!runQtCreatorForFile(absoluteFilePath)) {
        return;
    }

    rememberTouchedSourceFile(absoluteFilePath);
    standardOutput << trMessage(QStringLiteral("Qt Creator で編集しました: %1"),
                                QStringLiteral("Edited with Qt Creator: %1"))
                          .arg(fileInfo.fileName())
                   << Qt::endl;
    finishQrcEdit(historyEntry);
}

QFileInfo ReplSessionImpl::validateQrcFilePath(const QString& filePathArgument, const QString& commandName)
{
    const QString filePath = filePathArgument.trimmed();
    if (filePath.isEmpty()) {
        reportError(trMessage(QStringLiteral("%1 には .qrc ファイルパスが必要です。"),
                              QStringLiteral("%1 requires a .qrc file path."))
                        .arg(commandName));
        return {};
    }

    const QFileInfo fileInfo(filePath);
    if (!fileInfo.exists() || !fileInfo.isFile()) {
        reportError(trMessage(QStringLiteral("%1: .qrc ファイルが見つかりません。"),
                              QStringLiteral("%1: .qrc file not found."))
                        .arg(filePath));
        return {};
    }
    if (fileInfo.suffix().toLower() != QStringLiteral("qrc")) {
        reportError(trMessage(QStringLiteral("%1: .qrc ファイルではありません。"),
                              QStringLiteral("%1: Not a .qrc file."))
                        .arg(filePath));
        return {};
    }

    return fileInfo;
}

void ReplSessionImpl::finishQrcEdit(const QString& historyEntry)
{
    if (autogenEnabled) {
        generateQtFilesAndRun(historyEntry);
    } else {
        standardOutput << trMessage(QStringLiteral(".qrc を変更した場合は .gen で生成物を更新してください。"),
                                    QStringLiteral("If the .qrc file changed, run .gen to update generated files."))
                       << Qt::endl;
        addHistoryEntry(historyEntry);
    }
}

bool ReplSessionImpl::runDesignerForFile(const QString& filePath)
{
    const QString designerCommand = determineDesignerCommand();
    QStringList designerCommandParts = QProcess::splitCommand(designerCommand);
    if (designerCommandParts.isEmpty()) {
        reportError(trMessage(QStringLiteral("Designer コマンドを決定できません。ICPP_DESIGNER を設定してください。"),
                              QStringLiteral("Cannot determine the Designer command. Set ICPP_DESIGNER.")));
        return false;
    }

    const QString designerProgram = designerCommandParts.takeFirst();
    designerCommandParts.append(filePath);

    if (!QProcess::startDetached(designerProgram, designerCommandParts)) {
        reportError(trMessage(QStringLiteral("Designer を起動できません: %1"),
                              QStringLiteral("Cannot start Designer: %1"))
                        .arg(designerProgram));
        return false;
    }
    return true;
}

bool ReplSessionImpl::runLinguistForFile(const QString& filePath)
{
    const QString linguistCommand = determineLinguistCommand();
    QStringList linguistCommandParts = QProcess::splitCommand(linguistCommand);
    if (linguistCommandParts.isEmpty()) {
        reportError(trMessage(QStringLiteral("Linguist コマンドを決定できません。ICPP_LINGUIST を設定してください。"),
                              QStringLiteral("Cannot determine the Linguist command. Set ICPP_LINGUIST.")));
        return false;
    }

    const QString linguistProgram = linguistCommandParts.takeFirst();
    linguistCommandParts.append(filePath);

    if (!QProcess::startDetached(linguistProgram, linguistCommandParts)) {
        reportError(trMessage(QStringLiteral("Linguist を起動できません: %1"),
                              QStringLiteral("Cannot start Linguist: %1"))
                        .arg(linguistProgram));
        return false;
    }
    return true;
}

bool ReplSessionImpl::runQtCreatorForFile(const QString& filePath)
{
    const QString qtCreatorCommand = determineQtCreatorCommand();
    QStringList qtCreatorCommandParts = QProcess::splitCommand(qtCreatorCommand);
    if (qtCreatorCommandParts.isEmpty()) {
        reportError(trMessage(QStringLiteral("Qt Creator コマンドを決定できません。ICPP_QTCREATOR を設定してください。"),
                              QStringLiteral("Cannot determine the Qt Creator command. Set ICPP_QTCREATOR.")));
        return false;
    }

    const QString qtCreatorProgram = qtCreatorCommandParts.takeFirst();
    qtCreatorCommandParts.append(filePath);

    QProcess qtCreatorProcess;
    qtCreatorProcess.setInputChannelMode(QProcess::ForwardedInputChannel);
    qtCreatorProcess.setProcessChannelMode(QProcess::ForwardedChannels);
    qtCreatorProcess.start(qtCreatorProgram, qtCreatorCommandParts);

    if (!qtCreatorProcess.waitForStarted()) {
        reportError(trMessage(QStringLiteral("Qt Creator を起動できません: %1"),
                              QStringLiteral("Cannot start Qt Creator: %1"))
                        .arg(qtCreatorProgram));
        return false;
    }
    qtCreatorProcess.waitForFinished(-1);
    if (qtCreatorProcess.exitStatus() != QProcess::NormalExit) {
        reportError(trMessage(QStringLiteral("Qt Creator がクラッシュしました: %1"),
                              QStringLiteral("Qt Creator crashed: %1"))
                        .arg(qtCreatorProgram));
        return false;
    }
    if (qtCreatorProcess.exitCode() != 0) {
        reportError(trMessage(QStringLiteral("Qt Creator がステータス %1 で終了しました: %2"),
                              QStringLiteral("Qt Creator exited with status %1: %2"))
                        .arg(qtCreatorProcess.exitCode())
                        .arg(qtCreatorProgram));
        return false;
    }
    return true;
}

QString ReplSessionImpl::determineDesignerCommand() const
{
    QString designerCommand = qEnvironmentVariable("ICPP_DESIGNER");
    if (!designerCommand.trimmed().isEmpty()) {
        return designerCommand;
    }

    const QDir qtBinaryDirectory(QLibraryInfo::path(QLibraryInfo::BinariesPath));
#if defined(Q_OS_MACOS)
    const QString qtDesignerApp =
        qtBinaryDirectory.filePath(QStringLiteral("Designer.app/Contents/MacOS/Designer"));
    if (QFileInfo(qtDesignerApp).isExecutable()) {
        return qtDesignerApp;
    }
#endif

    const QString qtDesigner = qtBinaryDirectory.filePath(QStringLiteral("designer"));
    if (QFileInfo(qtDesigner).isExecutable()) {
        return qtDesigner;
    }

    const QString pathDesigner = QStandardPaths::findExecutable(QStringLiteral("designer"));
    if (!pathDesigner.isEmpty()) {
        return pathDesigner;
    }

    return {};
}

QString ReplSessionImpl::determineLinguistCommand() const
{
    QString linguistCommand = qEnvironmentVariable("ICPP_LINGUIST");
    if (!linguistCommand.trimmed().isEmpty()) {
        return linguistCommand;
    }

    const QDir qtBinaryDirectory(QLibraryInfo::path(QLibraryInfo::BinariesPath));
#if defined(Q_OS_MACOS)
    const QString qtLinguistApp =
        qtBinaryDirectory.filePath(QStringLiteral("Linguist.app/Contents/MacOS/Linguist"));
    if (QFileInfo(qtLinguistApp).isExecutable()) {
        return qtLinguistApp;
    }
#endif

    const QString qtLinguist = qtBinaryDirectory.filePath(QStringLiteral("linguist"));
    if (QFileInfo(qtLinguist).isExecutable()) {
        return qtLinguist;
    }

    const QString pathLinguist = QStandardPaths::findExecutable(QStringLiteral("linguist"));
    if (!pathLinguist.isEmpty()) {
        return pathLinguist;
    }

    return {};
}

QString ReplSessionImpl::determineQtCreatorCommand() const
{
    QString qtCreatorCommand = qEnvironmentVariable("ICPP_QTCREATOR");
    if (!qtCreatorCommand.trimmed().isEmpty()) {
        return qtCreatorCommand;
    }

#if defined(Q_OS_MACOS)
    const QString qtCreatorApp =
        QDir(QLibraryInfo::path(QLibraryInfo::PrefixPath))
            .filePath(QStringLiteral("../../Qt Creator.app/Contents/MacOS/Qt Creator"));
    const QString cleanQtCreatorApp = QDir::cleanPath(qtCreatorApp);
    if (QFileInfo(cleanQtCreatorApp).isExecutable()) {
        return QStringLiteral("\"%1\" -client -block").arg(cleanQtCreatorApp);
    }

    const QString applicationsQtCreator =
        QStringLiteral("/Applications/Qt Creator.app/Contents/MacOS/Qt Creator");
    if (QFileInfo(applicationsQtCreator).isExecutable()) {
        return QStringLiteral("\"%1\" -client -block").arg(applicationsQtCreator);
    }
#endif

    const QString pathQtCreator = QStandardPaths::findExecutable(QStringLiteral("qtcreator"));
    if (!pathQtCreator.isEmpty()) {
        return QStringLiteral("\"%1\" -client -block").arg(pathQtCreator);
    }

    return {};
}

void ReplSessionImpl::showUiInfo(const QString& filePathArgument, const QString& historyEntry)
{
    const QString filePath = filePathArgument.trimmed();
    if (filePath.isEmpty()) {
        reportError(trMessage(QStringLiteral(".uiinfo には .ui ファイルパスが必要です。"),
                              QStringLiteral(".uiinfo requires a .ui file path.")));
        return;
    }

    QFile inputFile(filePath);
    if (!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        reportError(trMessage(QStringLiteral("%1: .ui ファイルを開けません。"),
                              QStringLiteral("%1: Cannot open .ui file."))
                        .arg(filePath));
        return;
    }

    QString uiClassName;
    QString baseWidgetType;
    QList<UiObjectInfo> widgets;
    QList<UiObjectInfo> layouts;
    QList<UiObjectInfo> actions;
    QList<UiObjectInfo> spacers;

    QXmlStreamReader reader(&inputFile);
    while (!reader.atEnd()) {
        reader.readNext();
        if (!reader.isStartElement()) {
            continue;
        }

        const QStringView elementName = reader.name();
        if (elementName == QStringLiteral("class")) {
            uiClassName = reader.readElementText(QXmlStreamReader::SkipChildElements).trimmed();
            continue;
        }

        if (elementName == QStringLiteral("widget")) {
            const UiObjectInfo objectInfo = uiObjectInfoFromAttributes(reader.attributes());
            if (baseWidgetType.isEmpty()) {
                baseWidgetType = objectInfo.typeName;
            }
            widgets.append(objectInfo);
            continue;
        }

        if (elementName == QStringLiteral("layout")) {
            layouts.append(uiObjectInfoFromAttributes(reader.attributes()));
            continue;
        }

        if (elementName == QStringLiteral("action")) {
            UiObjectInfo actionInfo = uiObjectInfoFromAttributes(reader.attributes());
            if (actionInfo.typeName.isEmpty()) {
                actionInfo.typeName = QStringLiteral("QAction");
            }
            actions.append(actionInfo);
            continue;
        }

        if (elementName == QStringLiteral("spacer")) {
            UiObjectInfo spacerInfo = uiObjectInfoFromAttributes(reader.attributes());
            if (spacerInfo.typeName.isEmpty()) {
                spacerInfo.typeName = QStringLiteral("spacer");
            }
            spacers.append(spacerInfo);
        }
    }

    if (reader.hasError()) {
        reportError(trMessage(QStringLiteral("%1: .ui XML の読み取りに失敗しました: %2"),
                              QStringLiteral("%1: Failed to read .ui XML: %2"))
                        .arg(filePath, reader.errorString()));
        return;
    }

    standardOutput << trMessage(QStringLiteral("class: %1"), QStringLiteral("class: %1"))
                          .arg(uiClassName.isEmpty() ? trMessage(QStringLiteral("(未指定)"),
                                                                  QStringLiteral("(not specified)"))
                                                     : uiClassName)
                   << Qt::endl;
    standardOutput << trMessage(QStringLiteral("base: %1"), QStringLiteral("base: %1"))
                          .arg(baseWidgetType.isEmpty() ? trMessage(QStringLiteral("(未検出)"),
                                                                    QStringLiteral("(not detected)"))
                                                        : baseWidgetType)
                   << Qt::endl;
    standardOutput << Qt::endl;
    showUiObjectSection(trMessage(QStringLiteral("widgets:"), QStringLiteral("widgets:")), widgets);
    showUiObjectSection(trMessage(QStringLiteral("layouts:"), QStringLiteral("layouts:")), layouts);
    showUiObjectSection(trMessage(QStringLiteral("actions:"), QStringLiteral("actions:")), actions);
    showUiObjectSection(trMessage(QStringLiteral("spacers:"), QStringLiteral("spacers:")), spacers);
    addHistoryEntry(historyEntry);
}

UiObjectInfo ReplSessionImpl::uiObjectInfoFromAttributes(const QXmlStreamAttributes& attributes) const
{
    UiObjectInfo objectInfo;
    objectInfo.typeName = attributes.value(QStringLiteral("class")).toString();
    objectInfo.objectName = attributes.value(QStringLiteral("name")).toString();
    return objectInfo;
}

void ReplSessionImpl::showUiObjectSection(const QString& title, const QList<UiObjectInfo>& objects) const
{
    standardOutput << title << Qt::endl;
    if (objects.isEmpty()) {
        standardOutput << QStringLiteral("  %1")
                              .arg(trMessage(QStringLiteral("(なし)"), QStringLiteral("(none)")))
                       << Qt::endl;
        return;
    }

    int typeWidth = 0;
    for (const UiObjectInfo& objectInfo : objects) {
        typeWidth = std::max(typeWidth, static_cast<int>(objectInfo.typeName.size()));
    }

    for (const UiObjectInfo& objectInfo : objects) {
        standardOutput << QStringLiteral("  %1  %2")
                              .arg(objectInfo.typeName, -typeWidth)
                              .arg(objectInfo.objectName.isEmpty()
                                       ? trMessage(QStringLiteral("(名前なし)"),
                                                   QStringLiteral("(unnamed)"))
                                       : objectInfo.objectName)
                       << Qt::endl;
    }
    standardOutput << Qt::endl;
}

} // namespace icpp
