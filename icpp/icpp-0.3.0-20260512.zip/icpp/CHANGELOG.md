# Changelog

## 0.3.0 - 2026-05-12

### Added

- Contextual command help:
  - `.command -h`
  - `.command --help`
  - `.help <command>`
- Workflow/navigation commands:
  - `.examples`
  - `.where`
  - `.runorder`
  - `.qt`
- `.new <kind> [base]` as an alias for `.template <kind> [base]`.
- Starter templates for QWidget, Q_OBJECT, Designer UI, and resource examples.
- VS Code + Copilot guide and Qt Creator guide.

### Changed

- `.b` / `.buffer` defaults to off. The prompt shows `+b` when normal input is
  appended to the edit buffer.
- `.template` generated code now places `{` on cling-friendly definition lines.
- Short command help is printed directly; longer help uses the pager.
- Documentation now recommends matching the Qt 6.x.y version used by `icpp`,
  `qtcling`, `run_all`, Qt tools, QtUiTools, and PropertyEditor.

## 0.2.0 - 2026-05-09

### Added

- Default engine is `qtcling`.
- `--engine cling` and `--engine qtcling` selection.
- `.e` / `.edit` external editor workflow.
- `.r` / `.run` restart workflow.
- Multi-file workflow:
  - `.add <file>`
  - `.files`
  - `.drop <file|number>`
  - `.clearfiles`
- Clipboard workflow through external commands:
  - `.paste`
  - `.copy`
  - `ICPP_CLIPBOARD_PASTE`
  - `ICPP_CLIPBOARD_COPY`
- Value inspection:
  - `.p` / `.print`
  - `.ptype`
- Qt widget helpers:
  - `.widgets`
  - `.closeall`
- Unsaved edit buffer confirmation on `.q` / `.quit`.
- `examples/` with small Qt/C++ samples for `icpp`.
- `USER_GUIDE.md` and `USER_GUIDE.pdf`.
- Internal comparison notes for `ROOT + cling` and `qtcling + icpp`.

### Changed

- `.r` now restarts the interpreter, evaluates registered files in order, then
  evaluates the edit buffer.
- Help output is grouped by workflow.
- `USER_GUIDE.pdf` includes page numbers.

### Notes

- `icpp` remains a lightweight wrapper. It does not replace CMake projects or
  compile source files like ACLiC.
- The intended workflow is to use `icpp` for small Qt/C++ experiments, then move
  stable code into a regular CMake project.

## 0.1.0 - 2026-05-09

Initial internal prototype.
