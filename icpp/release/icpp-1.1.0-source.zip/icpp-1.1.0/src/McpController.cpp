#include "icpp/McpController.h"

#include "icpp/ReplHelpers.h"
#include "qmcpserver.h"

#include <QDir>
#include <QJsonArray>
#include <QJsonObject>
#include <QJsonValue>

#include <cmath>
#include <utility>

namespace icpp {
namespace {

constexpr qsizetype MaxSourceBytes = 1024 * 1024;
constexpr int DefaultTimeoutMilliseconds = 5000;
constexpr int MinimumTimeoutMilliseconds = 100;
constexpr int MaximumTimeoutMilliseconds = 30000;

QJsonObject emptyObjectSchema()
{
    return {{QStringLiteral("type"), QStringLiteral("object")}};
}

bool sourceAppearsIncomplete(const QString& sourceCode)
{
    int braceDelta = 0;
    const QStringList lines = normalizeSourceCode(sourceCode).split(QLatin1Char('\n'));
    for (const QString& line : lines) {
        braceDelta += braceDeltaOutsideQuotedText(line);
    }
    return braceDelta != 0;
}

bool readTimeout(const QJsonObject& arguments, int* timeout, QString* errorMessage)
{
    const QJsonValue value = arguments.value(QStringLiteral("timeoutMs"));
    if (value.isUndefined()) {
        *timeout = DefaultTimeoutMilliseconds;
        return true;
    }
    if (!value.isDouble() || !std::isfinite(value.toDouble())
        || std::floor(value.toDouble()) != value.toDouble()) {
        *errorMessage = QStringLiteral("timeoutMs must be an integer.");
        return false;
    }

    const int parsed = value.toInt(-1);
    if (parsed < MinimumTimeoutMilliseconds || parsed > MaximumTimeoutMilliseconds) {
        *errorMessage = QStringLiteral("timeoutMs must be between %1 and %2.")
                            .arg(MinimumTimeoutMilliseconds)
                            .arg(MaximumTimeoutMilliseconds);
        return false;
    }
    *timeout = parsed;
    return true;
}

} // namespace

McpController::McpController(Engine engine,
                             QString interpreterProgram,
                             QStringList interpreterArguments,
                             bool executionAllowed,
                             QObject* parent)
    : QObject(parent)
    , currentEngine(engine)
    , allowExecution(executionAllowed)
    , interpreter(engine, std::move(interpreterProgram), std::move(interpreterArguments))
    , server(new QMcpServer(this))
{
    server->setServerName(QStringLiteral("icpp"));
    server->setBuiltinToolPackMode(QMcpServer::BuiltinToolPackMode::CustomOnly);
    server->setApprovalPolicy(
        [this](const QString&, const QJsonObject&, QString* denyReason) {
            if (allowExecution) {
                return true;
            }
            if (denyReason) {
                *denyReason = QStringLiteral(
                    "Execution is disabled. Restart icpp with --mcp-allow-execution to enable it.");
            }
            return false;
        });
}

McpController::~McpController() = default;

bool McpController::startMessageTransport()
{
    return registerTools() && server->startMessageTransport();
}

bool McpController::processMessage(const QByteArray& message,
                                   QJsonObject* response,
                                   bool* hasResponse)
{
    const QMcpServer::MessageResult result = server->processMessage(message);
    if (response) {
        *response = result.response;
    }
    if (hasResponse) {
        *hasResponse = result.hasResponse;
    }
    return result.accepted;
}

QString McpController::negotiatedProtocolVersion() const
{
    return server->negotiatedProtocolVersion();
}

bool McpController::registerTools()
{
    if (toolsRegistered) {
        return true;
    }

    const bool statusRegistered = server->registerTool(
        QStringLiteral("icpp/session/status"),
        QStringLiteral("Return the icpp engine, interpreter state, working directory, and execution permission."),
        [this](const QJsonObject& arguments, QString* errorMessage) {
            return statusTool(arguments, errorMessage);
        },
        emptyObjectSchema());

    const bool evaluateRegistered = server->registerTool(
        QStringLiteral("icpp/code/evaluate"),
        QStringLiteral("Evaluate C++ or Qt code in the persistent interpreter for this MCP session."),
        [this](const QJsonObject& arguments, QString* errorMessage) {
            return evaluateTool(arguments, errorMessage);
        },
        QJsonObject{
            {QStringLiteral("type"), QStringLiteral("object")},
            {QStringLiteral("properties"), QJsonObject{
                 {QStringLiteral("source"), QJsonObject{
                      {QStringLiteral("type"), QStringLiteral("string")},
                      {QStringLiteral("minLength"), 1},
                      {QStringLiteral("maxLength"), int(MaxSourceBytes)},
                  }},
                 {QStringLiteral("timeoutMs"), QJsonObject{
                      {QStringLiteral("type"), QStringLiteral("integer")},
                      {QStringLiteral("minimum"), MinimumTimeoutMilliseconds},
                      {QStringLiteral("maximum"), MaximumTimeoutMilliseconds},
                  }},
             }},
            {QStringLiteral("required"), QJsonArray{QStringLiteral("source")}},
        },
        true);

    const bool resetRegistered = server->registerTool(
        QStringLiteral("icpp/session/reset"),
        QStringLiteral("Restart the interpreter and clear definitions in this MCP session."),
        [this](const QJsonObject& arguments, QString* errorMessage) {
            return resetTool(arguments, errorMessage);
        },
        emptyObjectSchema(),
        true);

    toolsRegistered = statusRegistered && evaluateRegistered && resetRegistered;
    return toolsRegistered;
}

QJsonObject McpController::statusTool(const QJsonObject&, QString*) const
{
    QJsonObject result{
        {QStringLiteral("engine"), engineName(currentEngine)},
        {QStringLiteral("interpreterRunning"), interpreter.isRunning()},
        {QStringLiteral("executionAllowed"), allowExecution},
        {QStringLiteral("workingDirectory"), QDir::currentPath()},
    };
    if (!interpreter.lastError().isEmpty()) {
        result.insert(QStringLiteral("lastError"), interpreter.lastError());
    }
    return result;
}

QJsonObject McpController::evaluateTool(const QJsonObject& arguments, QString* errorMessage)
{
    const QJsonValue sourceValue = arguments.value(QStringLiteral("source"));
    if (!sourceValue.isString() || sourceValue.toString().trimmed().isEmpty()) {
        *errorMessage = QStringLiteral("source must be a non-empty string.");
        return {};
    }
    const QString sourceCode = sourceValue.toString();
    if (sourceCode.contains(QChar::Null)) {
        *errorMessage = QStringLiteral("source must not contain NUL characters.");
        return {};
    }
    if (sourceCode.toUtf8().size() > MaxSourceBytes) {
        *errorMessage = QStringLiteral("source exceeds the 1 MiB limit.");
        return {};
    }
    if (sourceAppearsIncomplete(sourceCode)) {
        *errorMessage = QStringLiteral(
            "Input appears incomplete: unmatched { }. Close the block and evaluate again.");
        return {};
    }

    int timeoutMilliseconds = DefaultTimeoutMilliseconds;
    if (!readTimeout(arguments, &timeoutMilliseconds, errorMessage)) {
        return {};
    }

    const McpEvaluationResult evaluation = interpreter.evaluate(sourceCode, timeoutMilliseconds);
    return {
        {QStringLiteral("completed"), evaluation.completed},
        {QStringLiteral("timedOut"), evaluation.timedOut},
        {QStringLiteral("interpreterRunning"), evaluation.interpreterRunning},
        {QStringLiteral("outputTruncated"), evaluation.outputTruncated},
        {QStringLiteral("stdout"), evaluation.standardOutput},
        {QStringLiteral("stderr"), evaluation.standardError},
        {QStringLiteral("durationMs"), evaluation.durationMilliseconds},
        {QStringLiteral("error"), evaluation.errorMessage},
    };
}

QJsonObject McpController::resetTool(const QJsonObject&, QString* errorMessage)
{
    if (!interpreter.reset()) {
        *errorMessage = interpreter.lastError().isEmpty()
            ? QStringLiteral("The interpreter could not be reset.")
            : interpreter.lastError();
        return {};
    }
    return {
        {QStringLiteral("reset"), true},
        {QStringLiteral("interpreterRunning"), true},
    };
}

} // namespace icpp
