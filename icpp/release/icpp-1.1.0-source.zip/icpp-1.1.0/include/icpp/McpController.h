#pragma once

#include "icpp/McpInterpreterSession.h"

#include <QObject>

class QByteArray;
class QJsonObject;
class QMcpServer;

namespace icpp {

class McpController : public QObject
{
public:
    McpController(Engine engine,
                  QString interpreterProgram,
                  QStringList interpreterArguments,
                  bool executionAllowed,
                  QObject* parent = nullptr);
    ~McpController() override;

    bool startMessageTransport();
    bool processMessage(const QByteArray& message, QJsonObject* response, bool* hasResponse);
    QString negotiatedProtocolVersion() const;

private:
    bool registerTools();
    QJsonObject statusTool(const QJsonObject& arguments, QString* errorMessage) const;
    QJsonObject evaluateTool(const QJsonObject& arguments, QString* errorMessage);
    QJsonObject resetTool(const QJsonObject& arguments, QString* errorMessage);

    Engine currentEngine;
    bool allowExecution = false;
    McpInterpreterSession interpreter;
    QMcpServer* server = nullptr;
    bool toolsRegistered = false;
};

} // namespace icpp
