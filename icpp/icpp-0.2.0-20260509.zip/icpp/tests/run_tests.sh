#!/usr/bin/env bash
set -euo pipefail

icpp_bin="$(cd "$(dirname "$1")" && pwd)/$(basename "$1")"
tmp_dir="$(mktemp -d)"
trap 'rm -rf "$tmp_dir"' EXIT

cling_path="${ICPP_CLING:-/usr/local/src/cling/build/bin/cling}"

if [[ ! -x "$cling_path" ]]; then
    echo "Skipping icpp integration test: cling not found at $cling_path" >&2
    exit 0
fi

cat > "$tmp_dir/input.icpp" <<'EOF'
.args
#include <iostream>
int add(int a, int b) { return a + b; }
std::cout << add(2, 3) << std::endl;
.p add(2, 3)
.no_such_command
.errors
.show
.save saved.cpp
.reset
.open saved.cpp
.run
.quit
EOF

(
    cd "$tmp_dir"
    "$icpp_bin" --engine cling --cling "$cling_path" < input.icpp > output.txt 2>&1
)

grep -q "engine: cling" "$tmp_dir/output.txt"
grep -q "^5$" "$tmp_dir/output.txt"
grep -q "Unknown command: .no_such_command" "$tmp_dir/output.txt"
grep -q "2  int add" "$tmp_dir/output.txt"
grep -q "Saved: saved.cpp" "$tmp_dir/output.txt"
grep -q "Session reset." "$tmp_dir/output.txt"
grep -q "Opened: saved.cpp" "$tmp_dir/output.txt"

if [[ ! -s "$tmp_dir/saved.cpp" ]]; then
    echo "saved.cpp was not created" >&2
    exit 1
fi

cat > "$tmp_dir/help.icpp" <<'EOF'
.help
.quit
EOF

"$icpp_bin" --engine cling --cling "$cling_path" < "$tmp_dir/help.icpp" > "$tmp_dir/help.txt" 2>&1
grep -q ".loadlib <path>" "$tmp_dir/help.txt"

cat > "$tmp_dir/unsaved.icpp" <<'EOF'
int unsaved_value = 42;
.quit
N
.show
.quit
Y
EOF

"$icpp_bin" --engine cling --cling "$cling_path" < "$tmp_dir/unsaved.icpp" > "$tmp_dir/unsaved.txt" 2>&1
grep -q "Quit without saving? \\[Y/N\\]" "$tmp_dir/unsaved.txt"
grep -q "1  int unsaved_value = 42;" "$tmp_dir/unsaved.txt"

cat > "$tmp_dir/saved_quit.icpp" <<'EOF'
int saved_value = 42;
.save saved_quit.cpp
.quit
EOF

"$icpp_bin" --engine cling --cling "$cling_path" < "$tmp_dir/saved_quit.icpp" > "$tmp_dir/saved_quit.txt" 2>&1
if grep -q "Quit without saving" "$tmp_dir/saved_quit.txt"; then
    echo "saved buffer unexpectedly prompted before quit" >&2
    exit 1
fi

cat > "$tmp_dir/simple_class.cpp" <<'EOF'
class SimpleClass {
public:
    int getValue() const { return 21; }
};
EOF

cat > "$tmp_dir/use_simple_class.cpp" <<'EOF'
int makeValue() {
    SimpleClass value;
    return value.getValue() * 2;
}
EOF

cat > "$tmp_dir/files.icpp" <<EOF
.add $tmp_dir/simple_class.cpp
.add $tmp_dir/use_simple_class.cpp
.files
.r
.p makeValue()
.drop 1
.files
.clearfiles
.files
.quit
EOF

"$icpp_bin" --engine cling --cling "$cling_path" < "$tmp_dir/files.icpp" > "$tmp_dir/files.txt" 2>&1
grep -q "Added: $tmp_dir/simple_class.cpp" "$tmp_dir/files.txt"
grep -q "Added: $tmp_dir/use_simple_class.cpp" "$tmp_dir/files.txt"
grep -q "^42$" "$tmp_dir/files.txt"
grep -q "Dropped: $tmp_dir/simple_class.cpp" "$tmp_dir/files.txt"
grep -q "Registered files cleared." "$tmp_dir/files.txt"
grep -q "No registered files." "$tmp_dir/files.txt"

mkdir -p "$tmp_dir/clipboard-bin"
cat > "$tmp_dir/clipboard-bin/pbpaste" <<'EOF'
#!/usr/bin/env bash
printf 'int clipboard_value = 7;\nint doubled_clipboard_value() { return clipboard_value * 2; }\n'
EOF
cat > "$tmp_dir/clipboard-bin/pbcopy" <<EOF
#!/usr/bin/env bash
cat > "$tmp_dir/copied-buffer.cpp"
EOF
chmod +x "$tmp_dir/clipboard-bin/pbpaste" "$tmp_dir/clipboard-bin/pbcopy"

cat > "$tmp_dir/clipboard.icpp" <<'EOF'
.paste
.show
.copy
.r
.p doubled_clipboard_value()
.quit
Y
EOF

PATH="$tmp_dir/clipboard-bin:$PATH" "$icpp_bin" --engine cling --cling "$cling_path" \
    < "$tmp_dir/clipboard.icpp" > "$tmp_dir/clipboard.txt" 2>&1
grep -q "Pasted 2 lines." "$tmp_dir/clipboard.txt"
grep -q "Copied 2 lines." "$tmp_dir/clipboard.txt"
grep -q "1  int clipboard_value = 7;" "$tmp_dir/clipboard.txt"
grep -q "^14$" "$tmp_dir/clipboard.txt"
grep -q "doubled_clipboard_value" "$tmp_dir/copied-buffer.cpp"

echo "icpp integration tests passed"

qtcling_path="${ICPP_QTCLING:-/usr/local/src/cling/bin/qtcling}"

if [[ ! -x "$qtcling_path" ]]; then
    echo "Skipping qtcling integration test: qtcling not found at $qtcling_path" >&2
    exit 0
fi

cat > "$tmp_dir/default_engine.icpp" <<'EOF'
.args
.quit
EOF

ICPP_QTCLING="$qtcling_path" "$icpp_bin" < "$tmp_dir/default_engine.icpp" \
    > "$tmp_dir/default_engine.txt" 2>&1
grep -q "engine: qtcling" "$tmp_dir/default_engine.txt"

cat > "$tmp_dir/editor.sh" <<'EOF'
#!/usr/bin/env bash
cat > "$1" <<'CPP'
#include <QString>
#include <QVariant>
#include <QDebug>

QString concat(const QVariantList &args) {
    QString result;
    for (const QVariant &arg : args) {
        result += arg.toString();
    }
    return result;
}
CPP
EOF
chmod +x "$tmp_dir/editor.sh"

cat > "$tmp_dir/qt_edit.icpp" <<'EOF'
.edit
qDebug() << concat(QVariantList{QString("a"), QString("b")});
auto x = concat(QVariantList{12, 34, "a"});
.p x
.ptype x
.widgets
.closeall
.discard
.quit
EOF

ICPP_EDITOR="$tmp_dir/editor.sh" "$icpp_bin" --engine qtcling --qtcling "$qtcling_path" \
    < "$tmp_dir/qt_edit.icpp" > "$tmp_dir/qt_edit.txt" 2>&1
grep -q '"ab"' "$tmp_dir/qt_edit.txt"
grep -q '1234a' "$tmp_dir/qt_edit.txt"
grep -q 'QString' "$tmp_dir/qt_edit.txt"
grep -q 'No top-level widgets.' "$tmp_dir/qt_edit.txt"
grep -q 'Closed 0 widgets.' "$tmp_dir/qt_edit.txt"

echo "icpp qtcling edit tests passed"
