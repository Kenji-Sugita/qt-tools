---
genpdf:
  Format: book
  Title: icpp 利用ガイド
  Subtitle: cling / qtcling 対応 C++ REPL
  Author: (株) SRA
  version: 0.2.0
  page_numbers: true
---

<!-- page -->
!toc

<div class="page-break"></div>

<!-- page -->
# 1. 概要

`icpp` は、C++ を対話的に試すための REPL ラッパーです。

このガイドは `icpp 0.2.0` を対象にしています。

内部では `cling` または `qtcling` を起動し、ユーザー入力をその interpreter に送ります。`icpp` 自体は C++ を解釈しません。代わりに、次のような作業をしやすくします。

- 複数行の C++ コードを編集バッファとして扱う
- エディタで関数やクラスを編集する
- 編集したコードを最初から再実行する
- 複数ファイルを登録し、まとめて再実行する
- クリップボード経由でコードを出し入れする
- 試したコードをファイルへ保存する
- Qt 型の値を簡単に表示する

既定では `qtcling` を使います。そのため、`QString`、`QVariant`、`QDebug` など Qt の型をすぐ試せます。

配布物には、短い導入用の `README.md`、変更履歴の `CHANGELOG.md`、詳細な利用説明の `USER_GUIDE.pdf` を含めています。

!callout{type=note title=このガイドの前提}
  本文中の表は Markdown 表として、処理の流れは Mermaid 図として記述しています。
  PDF は `genpdf` で生成する前提です。

# 2. icpp でできること

`icpp` は、短い C++/Qt コードを試しながら育てるための道具です。

| 目的 | 使う機能 |
|---|---|
| C++ の式を試す | 通常入力 |
| Qt の型を試す | 既定の `qtcling` |
| 値を表示する | `.p` / `.print` |
| 型を表示する | `.ptype` |
| QWidget を確認する | `.widgets` |
| 複数行関数を書く | `.edit` / `.e` |
| 編集バッファを見る | `.show` |
| 編集バッファと登録ファイルを再実行する | `.run` |
| 複数ファイルをまとめて扱う | `.add` / `.files` / `.drop` |
| Copilot やエディタとコードをやり取りする | `.paste` / `.copy` |
| ファイルに保存する | `.save` |
| 既存ファイルを読む | `.open` / `.load` |
| interpreter を作り直す | `.reset` / `.restart` |

`icpp` は、本格的なビルドシステムや IDE の代替ではありません。小さな関数、データ変換、Qt 型の挙動確認を素早く行う用途に向いています。

# 3. cling / qtcling との関係

`icpp` は `cling` または `qtcling` を子プロセスとして起動します。

```mermaid
flowchart LR
  User[ユーザー入力] --> Icpp[icpp]
  Icpp -->|C++ コード| Interpreter[cling / qtcling]
  Interpreter -->|出力・エラー| Terminal[iTerm / Terminal]
  Icpp -->|編集バッファ管理| Buffer[編集バッファ]
```

`icpp` が担当するのは、入力管理、編集バッファ、ドットコマンド、ファイル操作です。C++ の評価やエラー診断は `cling` / `qtcling` が行います。

| エンジン | 用途 |
|---|---|
| `qtcling` | Qt 型や Qt ライブラリを使う。既定値 |
| `cling` | Qt を使わない C++ を試す |

## 3.1 cling の dot command との関係

`cling` には `.L`、`.x`、`.I`、`.printAST` などの metaprocessor command があります。ROOT 環境では、さらに `.U`、`.undo`、`.files` などのコマンドも使われます。

`icpp` では、先頭が `.` の入力はまず `icpp` 自身のコマンドとして扱います。そのため、`cling` や ROOT の dot command をそのまま入力しても、`icpp` の未知のコマンドとして扱われます。

```text
icpp[qtcling]> .L sample.C
Unknown command: .L
```

これは制限というより、`icpp` のコマンド体系と `cling` / ROOT の metaprocessor command を混在させないための設計です。`icpp` は、cling の内部状態を細かく操作するより、編集バッファと登録ファイルを管理し、`.r` で interpreter を作り直して再評価する作業モデルを採用しています。

主な対応関係は次の通りです。

| やりたいこと | cling / ROOT | icpp |
|---|---|---|
| ファイルを読み込む | `.L file.C` | `.load file.cpp` |
| ファイルを読み込み、関数を実行する | `.x file.C` | `.load` または `.add` + `.r` の後に関数を呼ぶ |
| include path を追加する | `.I path` | `.pragma add_include_path("path")` |
| ライブラリを読み込む | `.L libsample.dylib` | `.loadlib libsample.dylib` |
| 読み込んだファイルを外す | `.U file.C` | `.drop file.cpp` + `.r` |
| 複数ファイルを再評価する | `.L` を順番に実行 | `.add` / `.files` / `.r` |

`ROOT + cling` の dot command は ROOT の環境に依存するものがあります。通常の `qtcling` では同じコマンドが使えない場合があります。

<div class="page-break"></div>

<!-- page -->
# 4. 起動方法

## 4.1 既定の起動

通常はそのまま起動します。

```text
$ icpp
icpp[qtcling]>
```

既定のエンジンは `qtcling` です。

起動後、使用中のエンジンは `.args` で確認できます。

```text
icpp[qtcling]> .args
engine: qtcling
program: /usr/local/src/cling/bin/qtcling
arguments:
  --nologo
```

## 4.2 cling を使う

Qt を使わない C++ だけを試す場合は、`cling` を明示します。

```text
$ icpp --engine cling
icpp[cling]>
```

## 4.3 qtcling のパスを指定する

`qtcling` が PATH から見つからない場合や、特定の `qtcling` を使いたい場合はパスを指定します。

```text
$ icpp --engine qtcling --qtcling /usr/local/src/cling/bin/qtcling
```

`type qtcling` で `/usr/local/src/cling/bin/qtcling` が見えている場合は、パス指定は不要です。

```text
$ icpp --engine qtcling
```

## 4.4 起動後にエンジンを確認する

Qt ヘッダが見つからない場合は、まず `.args` を確認します。

```text
icpp[qtcling]> .args
```

| 表示 | 意味 |
|---|---|
| `engine: qtcling` | Qt 型を使える想定 |
| `engine: cling` | Qt 型はそのままでは使えない |

# 5. 基本的な使い方

## 5.1 1 行の式を実行する

式をそのまま入力できます。

```text
icpp[qtcling]> 1 + 2
(int) 3
```

C++ 文として扱いたい場合は、末尾に `;` を付けます。

```text
icpp[qtcling]> int x = 10;
icpp[qtcling]> x + 1
(int) 11
```

## 5.2 C++ 文を実行する

標準出力を使うこともできます。

```cpp
#include <iostream>
std::cout << "hello" << std::endl;
```

出力:

```text
hello
```

## 5.3 Qt の型を使う

既定では `qtcling` なので、Qt の型を使えます。

```cpp
#include <QString>

QString name = "Qt";
```

値を表示するには `.p` を使います。

```text
icpp[qtcling]> .p name
Qt
```

## 5.4 値を表示する

`QString` はそのまま入力すると内部表現に近い表示になる場合があります。

```text
icpp[qtcling]> QString s = "abc";
icpp[qtcling]> s
(QString &) { ... }
```

読みやすく表示するには `.p` を使います。

```text
icpp[qtcling]> .p s
abc
```

# 6. 編集バッファ

## 6.1 編集バッファとは

`icpp` は、入力した C++ コードを編集バッファに蓄積します。

```text
icpp[qtcling]> int x = 10;
icpp[qtcling]> int y = 20;
icpp[qtcling]> .show
1  int x = 10;
2  int y = 20;
```

`.p` や `.args` などの確認用コマンドは、編集バッファには追加されません。

## 6.2 .show で確認する

編集バッファ全体を表示します。

```text
icpp[qtcling]> .show
```

範囲指定もできます。

```text
icpp[qtcling]> .show 3
icpp[qtcling]> .show 3:8
```

## 6.3 .save で保存する

編集バッファをファイルへ保存します。

```text
icpp[qtcling]> .save sample.cpp
Saved: sample.cpp
```

一度保存した後は、ファイル名を省略できます。

```text
icpp[qtcling]> .save
```

## 6.4 .discard で消す

編集バッファを消します。interpreter のセッション自体は初期化しません。

```text
icpp[qtcling]> .discard
Edit buffer cleared.
```

# 7. エディタで編集する

## 7.1 .edit / .e

`.edit` または `.e` を使うと、編集バッファを外部エディタで開きます。

```text
icpp[qtcling]> .e
```

エディタを閉じると、`.run` と同じ流れで再実行します。登録ファイルがあれば先に評価し、その後で編集後のバッファを評価します。

```mermaid
flowchart TD
  Edit[.e / .edit] --> Temp[一時ファイルを作成]
  Temp --> Editor[外部エディタで編集]
  Editor --> Save[保存して閉じる]
  Save --> Restart[interpreter を再起動]
  Restart --> Files[登録ファイルを評価]
  Files --> Run[編集バッファ全体を実行]
```

## 7.2 使用するエディタの指定

エディタは次の順で決まります。

| 優先順位 | 環境変数または既定値 |
|---|---|
| 1 | `ICPP_EDITOR` |
| 2 | `VISUAL` |
| 3 | `EDITOR` |
| 4 | `vim` |

例:

```text
$ ICPP_EDITOR=vim icpp
```

## 7.3 編集後の再実行

`.e` は、編集後に `.run` と同じように登録ファイルとバッファ全体を再実行します。

そのため、関数を修正して保存すれば、現在のセッションでは新しい定義が使われます。

## 7.4 C++ の再定義エラーを避ける考え方

C++ では、同じセッションに同じ関数やクラス定義を再投入すると再定義エラーになることがあります。

`icpp` の `.run` と `.edit` は interpreter を再起動してからコードを実行するため、関数やクラスを修正しながら試す用途に向いています。

`icpp` では、クラス定義を同じセッションに上書きするのではなく、`.run` でセッションを作り直してから必要なコードを読み直す作業モデルに寄せています。

# 8. ファイルを使う

## 8.1 .open

`.open` は、ファイル内容で編集バッファを置き換えます。実行はしません。

```text
icpp[qtcling]> .open sample.cpp
Opened: sample.cpp
```

## 8.2 .load

`.load` は、ファイルを読み込んで現在のセッションで実行し、編集バッファにも追加します。

```text
icpp[qtcling]> .load sample.cpp
Loaded: sample.cpp
```

## 8.3 複数ファイルを登録する

`.add` は、`.run` / `.r` で評価するファイルを登録します。登録した時点では実行しません。

```text
icpp[qtcling]> .add SimpleClass.cpp
Added: /path/to/SimpleClass.cpp
icpp[qtcling]> .add UseSimpleClass.cpp
Added: /path/to/UseSimpleClass.cpp
```

登録済みファイルは `.files` で確認できます。

```text
icpp[qtcling]> .files
1  /path/to/SimpleClass.cpp
2  /path/to/UseSimpleClass.cpp
```

`.drop` は、番号またはファイルパスで登録を外します。

```text
icpp[qtcling]> .drop 1
Dropped: /path/to/SimpleClass.cpp
```

全て外す場合は `.clearfiles` を使います。

```text
icpp[qtcling]> .clearfiles
Registered files cleared.
```

## 8.4 .run

`.run` は interpreter を再起動し、登録ファイルを順番に実行してから、編集バッファ全体を実行します。

```text
icpp[qtcling]> .run
```

処理の順序は次の通りです。

```mermaid
flowchart TD
  Run[.run / .r] --> Restart[interpreter を再起動]
  Restart --> Files[登録ファイルを順番に評価]
  Files --> Buffer[編集バッファがあれば評価]
```

クラス定義を複数ファイルに分ける場合は、依存される側を先に `.add` します。

```text
icpp[qtcling]> .add SimpleClass.cpp
icpp[qtcling]> .add UseSimpleClass.cpp
icpp[qtcling]> .r
```

この運用では、クラス定義を修正した後も `.r` だけで interpreter を作り直して全体を読み直せます。

## 8.5 .reset と .restart

| コマンド | interpreter | 登録ファイル | 編集バッファ |
|---|---|---|---|
| `.restart` | 再起動する | 残す | 残す |
| `.run` / `.r` | 再起動する | 評価する | 評価する |
| `.reset` | 再起動する | 消す | 消す |

`.restart` は、interpreter の状態だけを作り直したいときに使います。

`.reset` は、作業を最初からやり直したいときに使います。

# 9. クリップボード連携

## 9.1 .paste

`.paste` は、クリップボードのテキストを編集バッファ末尾に追加します。貼り付けるだけで、評価はしません。

```text
icpp[qtcling]> .paste
Pasted 12 lines.
icpp[qtcling]> .show
```

貼り付けたコードを評価するには `.run` を使います。

```text
icpp[qtcling]> .r
```

## 9.2 .copy

`.copy` は、現在の編集バッファ全体をクリップボードへコピーします。

```text
icpp[qtcling]> .copy
Copied 12 lines.
```

## 9.3 使用する外部コマンド

`icpp` は `QClipboard` を使いません。`QCoreApplication` のまま動作するため、外部コマンド経由でクリップボードを扱います。

| 操作 | 探すコマンド |
|---|---|
| paste | `pbpaste`, `wl-paste`, `xclip`, `xsel` |
| copy | `pbcopy`, `wl-copy`, `xclip`, `xsel` |

明示指定する場合は環境変数を使います。

```text
$ ICPP_CLIPBOARD_PASTE=pbpaste ICPP_CLIPBOARD_COPY=pbcopy icpp
```

# 10. 表示用コマンド

## 10.1 .print / .p

`.p` は、式を表示するためのコマンドです。編集バッファには追加されません。

```text
icpp[qtcling]> QString s = "abc";
icpp[qtcling]> .p s
abc
```

`.print` と書いても同じです。

```text
icpp[qtcling]> .print s
abc
```

## 10.2 QString を表示する

`QString` は `.p` で表示するのが簡単です。

```text
icpp[qtcling]> QString name = "Qt";
icpp[qtcling]> .p name
Qt
```

## 10.3 QVariant / QStringList を表示する

Qt が `QDebug` で表示できる型は `.p` で確認できます。

```text
icpp[qtcling]> QVariant v = 123;
icpp[qtcling]> .p v
QVariant(int, 123)
```

```text
icpp[qtcling]> QStringList names{"a", "b"};
icpp[qtcling]> .p names
QList("a", "b")
```

## 10.4 qDebug() との違い

`qtcling` では、`.p expr` は内部的に次のような表示用コードを送ります。

```cpp
qDebug().noquote() << (expr);
```

毎回 `qDebug()` を書かずに値を確認するための短縮形です。

## 10.5 .ptype

`.ptype` は、式の C++ / Qt 型を確認するためのコマンドです。編集バッファには追加されません。

```text
icpp[qtcling]> QString s = "abc";
icpp[qtcling]> .ptype s
QString
```

テンプレート関数や `auto` で受けた値の型を確認するときに使います。

```text
icpp[qtcling]> auto names = QStringList{"a", "b"};
icpp[qtcling]> .ptype names
QStringList
```

`qtcling` では、Qt の meta type 名が分かる場合はそれを表示します。分からない型では C++ の `typeid` 名に近い表示になる場合があります。

## 10.6 .errors

`.errors` は、`icpp` のドットコマンド側で記録した直近のエラーを表示します。

```text
icpp[qtcling]> .no_such_command
Unknown command: .no_such_command
icpp[qtcling]> .errors
Unknown command: .no_such_command
```

対象は `icpp` が処理するコマンドのエラーです。C++ コードのコンパイルエラーや実行時の診断は、`cling` / `qtcling` から直接端末へ出力されるため、`.errors` には保存されません。

# 11. Qt コードを書く

## 11.1 QString / QVariant を使う

Qt 型を使うコードでは、通常どおり include を書きます。

```cpp
#include <QString>
#include <QVariant>
#include <QDebug>
```

`qtcling` で起動していれば、これらのヘッダを使えます。

## 11.2 可変個引数関数の例

任意個数の引数を文字列化して結合する関数の例です。

```cpp
// 任意個数の任意型引数を受け取り、それぞれを文字列化して結合した QString を返す。
// 例: auto s = concat(12, 34, "xyz");  // s は "1234xyz"

#include <QString>
#include <QVariant>
#include <utility>

inline QString concatToString(const char* value) {
    return QString::fromUtf8(value);
}

template <size_t N>
QString concatToString(const char (&value)[N]) {
    return QString::fromUtf8(value);
}

template <typename T>
QString concatToString(T&& value) {
    return QVariant::fromValue(std::forward<T>(value)).toString();
}

template <typename... Args>
QString concat(Args&&... args) {
    QString result;
    ((result += concatToString(std::forward<Args>(args))), ...);
    return result;
}
```

使い方:

```cpp
auto s = concat(12, 34, "xyz");
```

確認:

```text
icpp[qtcling]> .p s
1234xyz
```

## 11.3 文字列リテラルを扱う注意

`"xyz"` は `const char[4]` の配列として扱われます。

そのため、単純に次のように書くと失敗する場合があります。

```cpp
QVariant::fromValue("xyz")
```

文字列リテラルを扱う関数では、`const char*` や `const char (&)[N]` を明示的に `QString` に変換すると安全です。

## 11.4 よくある型エラー

次の関数は、引数を 1 個だけ受け取ります。

```cpp
QString concat(const QVariantList& args)
```

そのため、これはエラーです。

```cpp
concat(1, 2, 3)
```

呼び出すなら、`QVariantList` を 1 個渡します。

```cpp
concat(QVariantList{1, 2, 3})
```

`concat(1, 2, 3)` の形で呼びたい場合は、可変個引数テンプレートとして定義します。

# 12. ライブラリと pragma

## 12.1 .include

`.include` は include ディレクティブを送ります。

```text
icpp[qtcling]> .include QString
```

内部的には次を送ります。

```cpp
#include <QString>
```

明示的に `<...>` や `"..."` を書くこともできます。

```text
icpp[qtcling]> .include <QVariant>
```

## 12.2 .pragma

`.pragma` は `#pragma cling` を送ります。

```text
icpp[qtcling]> .pragma add_include_path("/path/to/include")
```

内部的には次を送ります。

```cpp
#pragma cling add_include_path("/path/to/include")
```

## 12.3 .loadlib

`.loadlib` は共有ライブラリを読み込むための短縮形です。

```text
icpp[qtcling]> .loadlib /path/to/libsample.dylib
```

内部的には次を送ります。

```cpp
#pragma cling load("/path/to/libsample.dylib")
```

## 12.4 #pragma cling load を直接書く

`#pragma cling` は直接入力しても構いません。

```cpp
#pragma cling load("/path/to/libsample.dylib")
```

`.loadlib` は、よく使う pragma の短縮形です。

# 13. コマンド一覧

## 13.1 セッション

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.help` | `.h`, `.?` | ヘルプを表示します |
| `.args` |  | 現在のエンジン、プログラム、引数を表示します |
| `.errors` |  | `icpp` コマンド側の直近エラーを表示します |
| `.quit` | `.q` | 終了します |

## 13.2 実行とリセット

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.run` | `.r` | interpreter を再起動し、登録ファイルと編集バッファを再実行します |
| `.restart` |  | interpreter を再起動します。登録ファイルと編集バッファは残します |
| `.reset` |  | interpreter を再起動し、登録ファイルと編集バッファを消します |

## 13.3 編集バッファ

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.edit` | `.e` | 編集バッファを外部エディタで開き、閉じた後に再実行します |
| `.show [range]` | `.sh` | 編集バッファを行番号付きで表示します |
| `.save [file]` | `.s` | 編集バッファを保存します |
| `.discard` | `.d` | 編集バッファを消去します |
| `.open <file>` | `.o` | ファイル内容で編集バッファを置き換えます。実行はしません |
| `.load <file>` | `.l` | ファイルを読み込んで実行し、編集バッファにも追加します |
| `.paste` |  | クリップボードのテキストを編集バッファへ追加します |
| `.copy` |  | 編集バッファをクリップボードへコピーします |

## 13.4 登録ファイル

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.add <file>` |  | `.run` で評価するファイルを登録します |
| `.files` |  | 登録ファイル一覧を表示します |
| `.drop <file|number>` |  | 登録ファイルを外します |
| `.clearfiles` |  | 登録ファイルを全て外します |

## 13.5 値の確認

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.print <expr>` | `.p` | 式を表示します。編集バッファには追加しません |
| `.ptype <expr>` |  | 式の C++ / Qt 型を表示します |

## 13.6 interpreter 操作

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.include <header>` |  | `#include` を送ります |
| `.pragma <text>` |  | `#pragma cling` を送ります |
| `.loadlib <path>` |  | `#pragma cling load(...)` を送ります |

## 13.7 Qt widget

| コマンド | 短縮形 | 説明 |
|---|---|---|
| `.widgets` |  | top-level QWidget 一覧を表示します |
| `.closeall` |  | top-level QWidget をまとめて閉じます |

# 14. Qt widget の確認

`.widgets` と `.closeall` は `qtcling` 用の補助コマンドです。`--engine cling` で起動している場合は使えません。

## 14.1 .widgets

`.widgets` は、現在存在する top-level `QWidget` の一覧を表示します。

```text
icpp[qtcling]> auto b = go();
icpp[qtcling]> .widgets
0x600001234000 QPushButton "Hello World" visible=true
```

GUI サンプルを試しているときに、どの widget が残っているか確認するために使います。

## 14.2 .closeall

`.closeall` は、top-level `QWidget` をまとめて閉じます。

```text
icpp[qtcling]> .closeall
Closed 1 widget.
```

REPL 上で複数の widget を試した後、ウィンドウをまとめて片付けたいときに使います。

## 14.3 使い方の例

`examples/08_push_button.cpp` を開いて実行します。

```text
icpp[qtcling]> .open examples/08_push_button.cpp
Opened: 08_push_button.cpp
icpp[qtcling]> .r
icpp[qtcling]> auto b = go();
icpp[qtcling]> .widgets
icpp[qtcling]> .closeall
```

# 15. 起動オプション一覧

| オプション | 説明 |
|---|---|
| `--engine qtcling` | `qtcling` を使います。既定値 |
| `--engine cling` | `cling` を使います |
| `--qtcling <path>` | `qtcling` のパスを指定します |
| `--cling <path>` | `cling` のパスを指定します |
| `--interpreter-arg <arg>` | 選択中の interpreter に追加引数を渡します |
| `--qtcling-arg <arg>` | `qtcling` 選択時だけ追加引数を渡します |
| `--cling-arg <arg>` | `cling` 選択時だけ追加引数を渡します |
| `--help` | ヘルプを表示します |
| `--version` | バージョンを表示します |

# 16. 環境変数

| 環境変数 | 説明 |
|---|---|
| `ICPP_QTCLING` | `qtcling` のパス |
| `ICPP_CLING` | `cling` のパス |
| `ICPP_EDITOR` | `.edit` で使うエディタ |
| `ICPP_CLIPBOARD_PASTE` | `.paste` で使う外部コマンド |
| `ICPP_CLIPBOARD_COPY` | `.copy` で使う外部コマンド |
| `VISUAL` | `ICPP_EDITOR` がない場合のエディタ |
| `EDITOR` | `VISUAL` がない場合のエディタ |

interpreter のパスは、次の順で決まります。

```mermaid
flowchart TD
  Cli[コマンドライン引数] --> Env[環境変数]
  Env --> Path[PATH 上のプログラム]
  Path --> Default[既知の既定パス]
```

# 17. よくあるエラー

## 17.1 QDebug file not found

例:

```text
fatal error: 'QDebug' file not found
```

`cling` で実行している可能性があります。

`.args` で確認します。

```text
icpp[qtcling]> .args
```

`engine: cling` と出ている場合は、`qtcling` で起動します。

```text
$ icpp --engine qtcling
```

## 17.2 QString が unknown type name になる

例:

```text
error: unknown type name 'QString'
```

主な原因は次のどちらかです。

| 原因 | 対処 |
|---|---|
| `#include <QString>` がない | include を追加する |
| `cling` で起動している | `qtcling` で起動する |

## 17.3 concat(1, 2, 3) が呼べない

関数が `QVariantList` を 1 個だけ受け取る定義になっている場合、次はエラーです。

```cpp
concat(1, 2, 3)
```

その場合は次のように呼びます。

```cpp
concat(QVariantList{1, 2, 3})
```

複数引数で呼びたい場合は、可変個引数テンプレートとして定義します。

## 17.4 QString の表示が分かりにくい

`QString` をそのまま入力すると、値ではなく内部表現に近い表示になる場合があります。

```text
icpp[qtcling]> QString s = "abc";
icpp[qtcling]> s
(QString &) { ... }
```

`.p` を使います。

```text
icpp[qtcling]> .p s
abc
```

## 17.5 再定義エラーが出る

同じセッションに同じ関数定義を何度も送ると、C++ の再定義エラーになる場合があります。

その場合は `.run`、`.edit`、または `.restart` を使って interpreter を作り直します。

```text
icpp[qtcling]> .run
```

`.run` は登録ファイルと編集バッファを再実行するので、関数やクラスを修正しながら試す作業に向いています。

複数のクラスを別々のファイルで育てる場合は、`.add` で登録してから `.r` します。

```text
icpp[qtcling]> .add A.cpp
icpp[qtcling]> .add B.cpp
icpp[qtcling]> .r
```

<div class="page-break"></div>

<!-- page -->
# 18. qtcling を直接使う場合との違い

`qtcling` を直接使うと、Qt/C++ をそのまま対話的に評価できます。

`icpp` はその上に、編集バッファとファイル操作を追加します。

| 項目 | qtcling 直接 | icpp |
|---|---|---|
| C++ 評価 | できる | できる |
| Qt 型 | 使える | 使える |
| 編集バッファ | なし | あり |
| `.edit` | なし | あり |
| `.save` | なし | あり |
| `.run` による再実行 | 手動 | あり |
| 複数ファイルの再評価 | 手動 | `.add` / `.files` / `.r` |
| クリップボード連携 | 手動 | `.paste` / `.copy` |
| `.p` による表示 | なし | あり |

短い確認だけなら `qtcling` 直接でも十分です。

関数を編集しながら育てたり、ファイルとして保存したりする場合は `icpp` が向いています。

# 19. ROOT + cling と qtcling + icpp

`ROOT + cling` と `qtcling + icpp` は、どちらも C++ を対話的に扱います。ただし、向いている利用者と実装方針は異なります。

## 19.1 利用者の違い

| 環境 | 向いている利用者 |
|---|---|
| `ROOT + cling` | ROOT の I/O、ヒストグラム、グラフ、データ解析、辞書生成を使う利用者 |
| `qtcling + icpp` | Qt/C++ の小さな実験、Qt 型の確認、widget 試作、Copilot で生成したコードの検証をする利用者 |

`ROOT + cling` は、ROOT のデータ解析環境に `cling` が統合されたものです。物理解析や大きなデータ処理、ROOT のオブジェクトモデルを使う作業に向いています。

`qtcling + icpp` は、`qtcling` を C++/Qt の評価エンジンとして使い、`icpp` が編集バッファ、複数ファイル、クリップボード、`.r` による再評価を担当します。Qt の API を試したり、短いクラスや関数を育てる作業に向いています。

## 19.2 クラス定義問題への方針の違い

`cling` では、一度定義したクラスを同じセッション内で再定義しにくいという制約があります。これは `ROOT + cling` でも `qtcling + icpp` でも意識する必要があります。

両者の対策は次のように異なります。

| 観点 | ROOT + cling | qtcling + icpp |
|---|---|---|
| 基本方針 | ROOT のマクロ、ロード、unload、辞書生成、ACLiC などを使う | interpreter を restart し、登録ファイルと編集バッファを最初から評価し直す |
| ファイル単位の扱い | `.L`, `.x`, `.U` など ROOT の meta command を使う | `.add`, `.files`, `.drop`, `.r` を使う |
| コンパイル | ACLiC でコンパイルして共有ライブラリとして扱える | コンパイルはしない。`cling` / `qtcling` へ解釈・JIT 評価させる |
| 再定義回避 | unload / reload や compiled library の運用に寄せる | 同じセッションへの上書きを避け、`.r` でセッションを作り直す |
| 向く段階 | 解析コードを ROOT の仕組みに乗せて使う段階 | CMake プロジェクト化する前に、Qt/C++ コードを試作する段階 |

`icpp` の複数ファイル管理は、ACLiC の代わりにコンパイルする仕組みではありません。位置づけとしては、ACLiC より軽い再評価ワークフローです。

```text
icpp[qtcling]> .add A.cpp
icpp[qtcling]> .add B.cpp
icpp[qtcling]> .r
```

この操作では、interpreter を再起動してから `A.cpp`、`B.cpp`、編集バッファの順に評価します。クラス定義を修正した場合でも、古い定義を同じセッションに上書きせず、セッションを作り直して読み直します。

## 19.3 使い分け

| やりたいこと | 向いている環境 |
|---|---|
| ROOT ファイルを読む、ヒストグラムを作る、解析マクロを回す | `ROOT + cling` |
| ROOT マクロをコンパイルして高速に動かす | `ROOT + ACLiC` |
| `QString`, `QVariant`, `QWidget` を対話的に試す | `qtcling + icpp` |
| Copilot が生成した Qt/C++ コードをすぐ実行して確認する | `qtcling + icpp` |
| 複数の小さな C++ ファイルを restart 前提で試す | `qtcling + icpp` |
| 配布するアプリやライブラリを作る | CMake プロジェクト |

# 20. 付録: 最小サンプル

## 20.1 QString を表示する

```text
icpp[qtcling]> #include <QString>
icpp[qtcling]> QString s = "hello";
icpp[qtcling]> .p s
hello
```

## 20.2 concat 関数を作る

`.e` で次のコードを書きます。

```cpp
#include <QString>
#include <QVariant>
#include <utility>

inline QString concatToString(const char* value) {
    return QString::fromUtf8(value);
}

template <size_t N>
QString concatToString(const char (&value)[N]) {
    return QString::fromUtf8(value);
}

template <typename T>
QString concatToString(T&& value) {
    return QVariant::fromValue(std::forward<T>(value)).toString();
}

template <typename... Args>
QString concat(Args&&... args) {
    QString result;
    ((result += concatToString(std::forward<Args>(args))), ...);
    return result;
}
```

呼び出します。

```text
icpp[qtcling]> auto s = concat(12, 34, "xyz");
icpp[qtcling]> .p s
1234xyz
```

## 20.3 保存して再利用する

```text
icpp[qtcling]> .save concat.cpp
Saved: concat.cpp
```

別のセッションで読みます。

```text
icpp[qtcling]> .open concat.cpp
Opened: concat.cpp
icpp[qtcling]> .run
```

## 20.4 cling を使う

Qt を使わない場合は、`cling` を明示できます。

```text
$ icpp --engine cling
icpp[cling]> 1 + 2
(int) 3
```

## 20.5 複数ファイルでクラスを試す

クラス定義と利用コードを別ファイルに分ける例です。

```cpp
// SimpleClass.cpp
class SimpleClass {
public:
    int getValue() const { return 100; }
};
```

```cpp
// UseSimpleClass.cpp
int makeValue() {
    SimpleClass s;
    return s.getValue() * 2;
}
```

`icpp` では依存順に登録します。

```text
icpp[qtcling]> .add SimpleClass.cpp
icpp[qtcling]> .add UseSimpleClass.cpp
icpp[qtcling]> .r
icpp[qtcling]> .p makeValue()
200
```

クラス定義を修正したら、もう一度 `.r` します。古い定義を同じセッションに上書きせず、interpreter を作り直して読み直します。

## 20.6 Copilot とクリップボードを使う

エディタで日本語コメントを書き、GitHub Copilot にコードを生成させます。

```cpp
// QStringList の全要素を大文字に変換して返す関数を作成する。
// 関数名は upperAll とし、引数と戻り値は QStringList とする。
```

生成されたコードをコピーし、`icpp` 側で貼り付けます。

```text
icpp[qtcling]> .paste
Pasted 12 lines.
icpp[qtcling]> .r
```

必要に応じて `.copy` で編集バッファをエディタ側へ戻します。

```text
icpp[qtcling]> .copy
Copied 12 lines.
```

## 20.7 同梱サンプルを使う

`examples/` には、`icpp` で試しやすい小さな Qt/C++ サンプルがあります。

各ファイルの先頭には、GitHub Copilot に同種のコードを生成させるための日本語コメントを入れています。`icpp` では、そのコメントも含めて `.open` し、`.run` で実行できます。

```text
icpp[qtcling]> .open examples/01_concat.cpp
Opened: 01_concat.cpp
icpp[qtcling]> .run
icpp[qtcling]> .p concatExample
1234xyz
```

| ファイル | 内容 | 確認例 |
|---|---|---|
| `examples/01_concat.cpp` | 任意個数の値を文字列化して結合する | `.p concatExample` |
| `examples/02_string_list.cpp` | `QStringList` の変換と結合 | `.p joinedNames` |
| `examples/03_variant_summary.cpp` | `QVariantList` の要約 | `.p variantSummary` |
| `examples/04_variant_map.cpp` | `QVariantMap` の key=value 整形 | `.p userText` |
| `examples/05_json.cpp` | `QVariantMap` を JSON に変換 | `.p settingsJson` |
| `examples/06_regular_expression.cpp` | 正規表現で数値を抽出 | `.p numbers` |
| `examples/07_timer.cpp` | `QTimer::singleShot` の確認 | `later()` |
| `examples/08_push_button.cpp` | `QPushButton` のクリック確認 | `auto b = go();` |
| `examples/09_table_widget.cpp` | `QTableWidget` の表示 | `auto t = showTable();` |
| `examples/10_file_info.cpp` | `QFileInfo` によるパス情報確認 | `.p currentDirSummary` |

GUI サンプルでは、通常の Qt アプリのような `main()` は書いていません。`go()` や `showTable()` を呼び出して、REPL 上で widget を作成します。

表示中の widget は次のコマンドで確認できます。

```text
icpp[qtcling]> .widgets
```

まとめて閉じる場合は次を使います。

```text
icpp[qtcling]> .closeall
```
