# Changelog

## 0.2.0 - 2026-05-09

### Added

- Default engine is `qtcling`.
- `--engine cling` and `--engine qtcling` selection.
- `.e` / `.edit` external editor workflow.
- `.r` / `.run` restart workflow.
- Multi-file workflow:
  - `.add <file>`
  - `.files`
  - `.drop <file|number>`
  - `.clearfiles`
- Clipboard workflow through external commands:
  - `.paste`
  - `.copy`
  - `ICPP_CLIPBOARD_PASTE`
  - `ICPP_CLIPBOARD_COPY`
- Value inspection:
  - `.p` / `.print`
  - `.ptype`
- Qt widget helpers:
  - `.widgets`
  - `.closeall`
- Unsaved edit buffer confirmation on `.q` / `.quit`.
- `examples/` with small Qt/C++ samples for `icpp`.
- `USER_GUIDE.md` and `USER_GUIDE.pdf`.
- Internal comparison notes for `ROOT + cling` and `qtcling + icpp`.

### Changed

- `.r` now restarts the interpreter, evaluates registered files in order, then
  evaluates the edit buffer.
- Help output is grouped by workflow.
- `USER_GUIDE.pdf` includes page numbers.

### Notes

- `icpp` remains a lightweight wrapper. It does not replace CMake projects or
  compile source files like ACLiC.
- The intended workflow is to use `icpp` for small Qt/C++ experiments, then move
  stable code into a regular CMake project.

## 0.1.0 - 2026-05-09

Initial internal prototype.
