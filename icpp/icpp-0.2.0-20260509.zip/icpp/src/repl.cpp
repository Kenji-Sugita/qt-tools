#include "icpp/repl.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProcess>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QTemporaryFile>
#include <QTextStream>
#include <QThread>

#if defined(HAVE_READLINE)
#include <readline/history.h>
#include <readline/readline.h>
#endif

#if defined(Q_OS_WIN)
#include <windows.h>
#else
#include <unistd.h>
#endif

#include <cstdlib>
#include <iostream>
#include <optional>
#include <utility>

namespace {

using icpp::Engine;
using icpp::engineName;

constexpr auto kDefaultEditor = "vim";
constexpr auto kDefaultClingPath = "/usr/local/src/cling/build/bin/cling";
constexpr auto kDefaultQtClingPath = "/usr/local/src/cling/bin/qtcling";

constexpr auto kUsageText = R"(Session
  .help, .h, .?                 Show this help
  .args                         Show the active interpreter program and arguments
  .errors                       Show recent icpp command errors
  .quit, .q                     Quit icpp

Run and reset
  .run, .r                      Restart and evaluate registered files, then buffer
  .restart                      Restart the interpreter and keep files and buffer
  .reset                        Restart the interpreter and clear files and buffer

Edit buffer
  .edit, .e                     Edit the buffer, then run
  .show, .sh [range]            Show the buffer with line numbers
  .save, .s [file]              Save the buffer
  .discard, .d                  Clear the buffer
  .open, .o <file>              Replace the buffer with a file without evaluating it
  .load, .l <file>              Load, evaluate, and append a file to the buffer
  .paste                        Append clipboard text to the buffer
  .copy                         Copy the buffer to the clipboard

Registered files
  .add <file>                   Add a file evaluated by .run/.r
  .files                        Show files evaluated by .run/.r
  .drop <file|number>           Remove a registered file
  .clearfiles                   Clear registered files

Inspect values
  .print, .p <expr>             Print an expression without changing the buffer
  .ptype <expr>                 Print the C++/Qt type of an expression

Interpreter
  .include <header>             Send #include <header>
  .pragma <text>                Send #pragma cling <text>
  .loadlib <path>               Send #pragma cling load("path")

Qt widgets
  .widgets                      Show top-level QWidget objects
  .closeall                     Close top-level QWidget objects

Range syntax for .show: start or start:end
Examples: .show 3   .show 3:8)";

QTextStream& standardOutput()
{
    static QTextStream stream(stdout);
    return stream;
}

QTextStream& standardError()
{
    static QTextStream stream(stderr);
    return stream;
}

struct ParsedCommand {
    QString commandName;
    QString argument;
};

struct ShowRange {
    int startLine = 1;
    int endLine = 1;
};

struct ClipboardCommand {
    QString program;
    QStringList arguments;
};

bool shouldShowPrompt()
{
#if defined(Q_OS_WIN)
    HANDLE handle = GetStdHandle(STD_INPUT_HANDLE);
    if (handle == INVALID_HANDLE_VALUE || handle == nullptr) {
        return false;
    }

    DWORD consoleMode = 0;
    return GetConsoleMode(handle, &consoleMode) != 0;
#else
    return isatty(STDIN_FILENO);
#endif
}

std::optional<QString> readConsoleLine(const QString& promptText)
{
#if defined(HAVE_READLINE)
    if (shouldShowPrompt()) {
        const QByteArray promptBytes = promptText.toLocal8Bit();
        char* rawLine = ::readline(promptBytes.constData());
        if (rawLine == nullptr) {
            return std::nullopt;
        }

        const QString line = QString::fromLocal8Bit(rawLine);
        std::free(rawLine);
        return line;
    }
#endif
    if (shouldShowPrompt()) {
        standardOutput() << promptText << Qt::flush;
    }

    static QTextStream standardInput(stdin);
    const QString line = standardInput.readLine();
    if (line.isNull()) {
        return std::nullopt;
    }

    return line;
}

ParsedCommand parseCommand(const QString& trimmedLine)
{
    const QStringList commandParts =
        trimmedLine.split(QRegularExpression(QStringLiteral("\\s+")), Qt::SkipEmptyParts);
    if (commandParts.isEmpty()) {
        return {};
    }

    const QString commandName = commandParts.first();
    const int commandEnd = trimmedLine.indexOf(commandName) + commandName.size();
    return {commandName, trimmedLine.mid(commandEnd).trimmed()};
}

QString normalizeSourceCode(const QString& sourceCode)
{
    QString normalized = sourceCode;
    normalized.replace(QStringLiteral("\r\n"), QStringLiteral("\n"));
    normalized.replace(QLatin1Char('\r'), QLatin1Char('\n'));
    while (normalized.endsWith(QLatin1Char('\n'))) {
        normalized.chop(1);
    }
    return normalized;
}

QString joinSourceCode(const QStringList& blocks)
{
    QStringList nonEmptyBlocks;
    for (const QString& block : blocks) {
        const QString normalized = normalizeSourceCode(block);
        if (!normalized.isEmpty()) {
            nonEmptyBlocks.append(normalized);
        }
    }
    return nonEmptyBlocks.join(QStringLiteral("\n"));
}

std::optional<QString> readTextFile(const QString& filePath)
{
    QFile inputFile(filePath);
    if (!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        standardError() << QStringLiteral("%1: Cannot open.").arg(filePath) << Qt::endl;
        return std::nullopt;
    }

    QTextStream inputStream(&inputFile);
    return inputStream.readAll();
}

bool writeTextFile(const QString& filePath, const QString& sourceCode)
{
    QFile outputFile(filePath);
    if (!outputFile.open(QIODevice::WriteOnly | QIODevice::Text | QIODevice::Truncate)) {
        standardError() << QStringLiteral("%1: Cannot write.").arg(filePath) << Qt::endl;
        return false;
    }

    QTextStream outputStream(&outputFile);
    outputStream << sourceCode;
    if (!sourceCode.endsWith(QLatin1Char('\n'))) {
        outputStream << Qt::endl;
    }
    outputStream.flush();
    return outputStream.status() == QTextStream::Ok;
}

QString quoteForPragma(const QString& path)
{
    QString quoted = path;
    quoted.replace(QLatin1Char('\\'), QStringLiteral("\\\\"));
    quoted.replace(QLatin1Char('"'), QStringLiteral("\\\""));
    return quoted;
}

std::optional<ShowRange> parseShowRange(const QString& rangeArgument, int availableLineCount)
{
    if (availableLineCount <= 0) {
        return ShowRange{1, 0};
    }

    const QString trimmed = rangeArgument.trimmed();
    if (trimmed.isEmpty()) {
        return ShowRange{1, availableLineCount};
    }

    const QRegularExpression pattern(QStringLiteral(R"(^(\d+)(?::(\d+))?$)"));
    const QRegularExpressionMatch match = pattern.match(trimmed);
    if (!match.hasMatch()) {
        return std::nullopt;
    }

    const int startLine = match.captured(1).toInt();
    const int endLine = match.captured(2).isEmpty() ? startLine : match.captured(2).toInt();
    if (startLine <= 0 || endLine < startLine) {
        return std::nullopt;
    }

    return ShowRange{qMin(startLine, availableLineCount), qMin(endLine, availableLineCount)};
}

QString findProgramInPath(const QString& programName)
{
    const QString foundPath = QStandardPaths::findExecutable(programName);
    if (!foundPath.isEmpty()) {
        return foundPath;
    }
    return {};
}

std::optional<ClipboardCommand> clipboardCommandFromEnvironment(const char* environmentVariable)
{
    const QString commandText = qEnvironmentVariable(environmentVariable).trimmed();
    if (commandText.isEmpty()) {
        return std::nullopt;
    }

    QStringList commandParts = QProcess::splitCommand(commandText);
    if (commandParts.isEmpty()) {
        return std::nullopt;
    }

    ClipboardCommand command;
    command.program = commandParts.takeFirst();
    command.arguments = commandParts;
    return command;
}

std::optional<ClipboardCommand> findClipboardReadCommand()
{
    if (const std::optional<ClipboardCommand> command =
            clipboardCommandFromEnvironment("ICPP_CLIPBOARD_PASTE")) {
        return command;
    }

    struct Candidate {
        const char* program;
        QStringList arguments;
    };
    const Candidate candidates[] = {
        {"pbpaste", {}},
        {"wl-paste", {}},
        {"xclip", {QStringLiteral("-selection"), QStringLiteral("clipboard"), QStringLiteral("-o")}},
        {"xsel", {QStringLiteral("--clipboard"), QStringLiteral("--output")}},
    };

    for (const Candidate& candidate : candidates) {
        const QString programPath = findProgramInPath(QString::fromLatin1(candidate.program));
        if (!programPath.isEmpty()) {
            return ClipboardCommand{programPath, candidate.arguments};
        }
    }
    return std::nullopt;
}

std::optional<ClipboardCommand> findClipboardWriteCommand()
{
    if (const std::optional<ClipboardCommand> command =
            clipboardCommandFromEnvironment("ICPP_CLIPBOARD_COPY")) {
        return command;
    }

    struct Candidate {
        const char* program;
        QStringList arguments;
    };
    const Candidate candidates[] = {
        {"pbcopy", {}},
        {"wl-copy", {}},
        {"xclip", {QStringLiteral("-selection"), QStringLiteral("clipboard")}},
        {"xsel", {QStringLiteral("--clipboard"), QStringLiteral("--input")}},
    };

    for (const Candidate& candidate : candidates) {
        const QString programPath = findProgramInPath(QString::fromLatin1(candidate.program));
        if (!programPath.isEmpty()) {
            return ClipboardCommand{programPath, candidate.arguments};
        }
    }
    return std::nullopt;
}

QString resolveInterpreterProgramImpl(Engine engine,
                                      const QString& commandLinePath,
                                      QTextStream& errorStream)
{
    if (!commandLinePath.trimmed().isEmpty()) {
        return commandLinePath;
    }

    const QByteArray envName = engine == Engine::Cling ? QByteArray("ICPP_CLING")
                                                       : QByteArray("ICPP_QTCLING");
    const QString environmentPath = QString::fromLocal8Bit(qgetenv(envName.constData()));
    if (!environmentPath.trimmed().isEmpty()) {
        return environmentPath;
    }

    const QString programName = engineName(engine);
    const QString pathProgram = findProgramInPath(programName);
    if (!pathProgram.isEmpty()) {
        return pathProgram;
    }

    const QString knownPath = engine == Engine::Cling ? QString::fromLatin1(kDefaultClingPath)
                                                      : QString::fromLatin1(kDefaultQtClingPath);
    if (QFileInfo::exists(knownPath)) {
        return knownPath;
    }

    errorStream << QStringLiteral("Cannot find %1. Use --%1 <path> or ICPP_%2.")
                       .arg(programName, programName.toUpper())
                << Qt::endl;
    return {};
}

class InterpreterProcess
{
public:
    InterpreterProcess(Engine engine,
                       QString program,
                       QStringList extraArguments,
                       QTextStream& output,
                       QTextStream& error)
        : currentEngine(engine)
        , programPath(std::move(program))
        , additionalArguments(std::move(extraArguments))
        , standardOutput(output)
        , standardError(error)
    {
    }

    ~InterpreterProcess()
    {
        stop();
    }

    bool start()
    {
        if (programPath.isEmpty()) {
            return false;
        }

        interpreterProcess.setProgram(programPath);
        interpreterProcess.setArguments(arguments());
        interpreterProcess.setProcessChannelMode(QProcess::ForwardedChannels);
        interpreterProcess.start();
        if (!interpreterProcess.waitForStarted()) {
            standardError << QStringLiteral("Cannot start %1: %2")
                                 .arg(programPath, interpreterProcess.errorString())
                          << Qt::endl;
            return false;
        }
        waitForInterpreterStartupToSettle();
        return true;
    }

    bool restart()
    {
        stop();
        return start();
    }

    void stop()
    {
        if (interpreterProcess.state() == QProcess::NotRunning) {
            return;
        }

        interpreterProcess.closeWriteChannel();
        if (!interpreterProcess.waitForFinished(500)) {
            interpreterProcess.terminate();
        }
        if (!interpreterProcess.waitForFinished(1000)) {
            interpreterProcess.kill();
            interpreterProcess.waitForFinished(1000);
        }
    }

    bool sendSource(const QString& sourceCode)
    {
        if (interpreterProcess.state() == QProcess::NotRunning && !start()) {
            return false;
        }

        QString source = sourceCode;
        if (!source.endsWith(QLatin1Char('\n'))) {
            source.append(QLatin1Char('\n'));
        }

        interpreterProcess.write(source.toLocal8Bit());
        if (!interpreterProcess.waitForBytesWritten(1000)) {
            standardError << QStringLiteral("Cannot write to %1: %2")
                                 .arg(programPath, interpreterProcess.errorString())
                          << Qt::endl;
            return false;
        }

        waitForBatchInputToSettle();
        return true;
    }

    void showArguments() const
    {
        standardOutput << QStringLiteral("engine: %1").arg(engineName(currentEngine)) << Qt::endl;
        standardOutput << QStringLiteral("program: %1").arg(programPath) << Qt::endl;
        standardOutput << QStringLiteral("arguments:");
        const QStringList currentArguments = arguments();
        if (currentArguments.isEmpty()) {
            standardOutput << QStringLiteral(" (none)") << Qt::endl;
            return;
        }
        standardOutput << Qt::endl;
        for (const QString& argument : currentArguments) {
            standardOutput << QStringLiteral("  %1").arg(argument) << Qt::endl;
        }
    }

private:
    QStringList arguments() const
    {
        QStringList result;
        result << QStringLiteral("--nologo");
        result << additionalArguments;
        return result;
    }

    void waitForBatchInputToSettle()
    {
        QThread::msleep(1000);
    }

    void waitForInterpreterStartupToSettle()
    {
        QThread::msleep(1000);
    }

    Engine currentEngine;
    QString programPath;
    QStringList additionalArguments;
    QTextStream& standardOutput;
    QTextStream& standardError;
    QProcess interpreterProcess;
};

class ReplSessionImpl
{
public:
    ReplSessionImpl(Engine engine,
                QString programPath,
                QStringList interpreterArguments,
                QTextStream& output,
                QTextStream& error)
        : currentEngine(engine)
        , interpreter(engine, std::move(programPath), std::move(interpreterArguments), output, error)
        , standardOutput(output)
        , standardError(error)
    {
    }

    int run()
    {
        if (!interpreter.start()) {
            return 1;
        }

        while (!shouldQuit) {
            const std::optional<QString> line = readConsoleLine(prompt());
            if (!line.has_value()) {
                break;
            }

            const QString trimmedLine = line->trimmed();
            if (trimmedLine.isEmpty()) {
                continue;
            }

            if (trimmedLine.startsWith(QLatin1Char('.'))) {
                handleCommand(trimmedLine);
            } else {
                appendSource(*line);
                interpreter.sendSource(*line);
                addHistoryEntry(*line);
            }
        }

        return 0;
    }

private:
    QString prompt() const
    {
        return QStringLiteral("icpp[%1]> ").arg(engineName(currentEngine));
    }

    void handleCommand(const QString& trimmedLine)
    {
        const ParsedCommand parsedCommand = parseCommand(trimmedLine);
        const QString& commandName = parsedCommand.commandName;

        if (commandName == QStringLiteral(".quit") || commandName == QStringLiteral(".q")) {
            shouldQuit = confirmQuitIfVisibleBufferHasUnsavedChanges();
            return;
        }

        if (commandName == QStringLiteral(".help") || commandName == QStringLiteral(".h")
            || commandName == QStringLiteral(".?")) {
            standardOutput << kUsageText << Qt::endl;
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".args")) {
            interpreter.showArguments();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".errors")) {
            showRecentErrors();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".show") || commandName == QStringLiteral(".sh")) {
            showVisibleSourceCode(parsedCommand.argument);
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".files")) {
            showRegisteredSourceFiles();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".paste")) {
            pasteClipboardIntoVisibleBuffer(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".copy")) {
            copyVisibleBufferToClipboard(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".add")) {
            addRegisteredSourceFile(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".drop")) {
            dropRegisteredSourceFile(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".clearfiles")) {
            clearRegisteredSourceFiles();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".discard") || commandName == QStringLiteral(".d")) {
            discardVisibleSourceCode();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".run") || commandName == QStringLiteral(".r")) {
            runVisibleSourceCode();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".restart")) {
            restartInterpreter();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".reset")) {
            resetSession();
            addHistoryEntry(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".open") || commandName == QStringLiteral(".o")) {
            openFileIntoVisibleBuffer(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".load") || commandName == QStringLiteral(".l")) {
            loadAndEvaluateFile(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".save") || commandName == QStringLiteral(".s")) {
            saveVisibleBuffer(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".edit") || commandName == QStringLiteral(".e")) {
            openEditor(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".print") || commandName == QStringLiteral(".p")) {
            printExpression(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".ptype")) {
            printExpressionType(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".widgets")) {
            showWidgets(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".closeall")) {
            closeAllWidgets(trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".loadlib")) {
            loadLibrary(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".include")) {
            includeHeader(parsedCommand.argument, trimmedLine);
            return;
        }

        if (commandName == QStringLiteral(".pragma")) {
            sendPragma(parsedCommand.argument, trimmedLine);
            return;
        }

        reportError(QStringLiteral("Unknown command: %1").arg(commandName));
    }

    QString visibleSourceCode() const
    {
        return joinSourceCode(committedSourceCode);
    }

    void replaceVisibleSourceCode(const QString& sourceCode)
    {
        committedSourceCode.clear();
        const QString normalized = normalizeSourceCode(sourceCode);
        if (!normalized.isEmpty()) {
            committedSourceCode.append(normalized);
        }
    }

    void appendSource(const QString& sourceCode)
    {
        const QString normalized = normalizeSourceCode(sourceCode);
        if (!normalized.isEmpty()) {
            committedSourceCode.append(normalized);
        }
    }

    void showVisibleSourceCode(const QString& rangeArgument)
    {
        const QString sourceCodeToShow = visibleSourceCode();
        if (sourceCodeToShow.isEmpty()) {
            standardOutput << QStringLiteral("Edit buffer is empty.") << Qt::endl;
            return;
        }

        const QStringList allLines = sourceCodeToShow.split(QLatin1Char('\n'));
        const std::optional<ShowRange> showRange = parseShowRange(rangeArgument, allLines.size());
        if (!showRange.has_value()) {
            reportError(QStringLiteral("Invalid range. Use .show, .show 3, or .show 3:8"));
            return;
        }

        const int lineNumberWidth = QString::number(showRange->endLine).size();
        for (int lineNumber = showRange->startLine; lineNumber <= showRange->endLine; ++lineNumber) {
            standardOutput << QStringLiteral("%1  %2")
                                  .arg(lineNumber, lineNumberWidth)
                                  .arg(allLines.at(lineNumber - 1))
                           << Qt::endl;
        }
    }

    void discardVisibleSourceCode()
    {
        if (committedSourceCode.isEmpty()) {
            standardOutput << QStringLiteral("Edit buffer is already empty.") << Qt::endl;
            return;
        }

        committedSourceCode.clear();
        rememberedVisibleBufferFilePath.clear();
        lastSavedVisibleSourceCode.clear();
        standardOutput << QStringLiteral("Edit buffer cleared.") << Qt::endl;
    }

    void runVisibleSourceCode()
    {
        const QString sourceCodeToEvaluate = visibleSourceCode();
        if (registeredSourceFilePaths.isEmpty() && sourceCodeToEvaluate.isEmpty()) {
            reportError(QStringLiteral("No files or edit buffer to run."));
            return;
        }

        if (interpreter.restart()) {
            for (const QString& filePath : registeredSourceFilePaths) {
                const std::optional<QString> sourceCode = readTextFile(filePath);
                if (!sourceCode.has_value()) {
                    return;
                }
                interpreter.sendSource(*sourceCode);
            }
            if (!sourceCodeToEvaluate.isEmpty()) {
                interpreter.sendSource(sourceCodeToEvaluate);
            }
        }
    }

    void restartInterpreter()
    {
        if (interpreter.restart()) {
            standardOutput << QStringLiteral("Interpreter restarted.") << Qt::endl;
        }
    }

    void resetSession()
    {
        if (interpreter.restart()) {
            committedSourceCode.clear();
            registeredSourceFilePaths.clear();
            rememberedVisibleBufferFilePath.clear();
            lastSavedVisibleSourceCode.clear();
            standardOutput << QStringLiteral("Session reset.") << Qt::endl;
        }
    }

    void showRegisteredSourceFiles()
    {
        if (registeredSourceFilePaths.isEmpty()) {
            standardOutput << QStringLiteral("No registered files.") << Qt::endl;
            return;
        }

        const int lineNumberWidth = QString::number(registeredSourceFilePaths.size()).size();
        for (int index = 0; index < registeredSourceFilePaths.size(); ++index) {
            standardOutput << QStringLiteral("%1  %2")
                                  .arg(index + 1, lineNumberWidth)
                                  .arg(registeredSourceFilePaths.at(index))
                           << Qt::endl;
        }
    }

    void pasteClipboardIntoVisibleBuffer(const QString& historyEntry)
    {
        const std::optional<ClipboardCommand> command = findClipboardReadCommand();
        if (!command.has_value()) {
            reportError(QStringLiteral("Cannot find a clipboard paste command."));
            return;
        }

        QProcess clipboardProcess;
        clipboardProcess.start(command->program, command->arguments);
        if (!clipboardProcess.waitForStarted()) {
            reportError(QStringLiteral("Cannot start clipboard paste command: %1").arg(command->program));
            return;
        }
        if (!clipboardProcess.waitForFinished(3000)) {
            clipboardProcess.kill();
            clipboardProcess.waitForFinished(1000);
            reportError(QStringLiteral("Clipboard paste command timed out."));
            return;
        }
        if (clipboardProcess.exitStatus() != QProcess::NormalExit || clipboardProcess.exitCode() != 0) {
            const QString errorText = QString::fromLocal8Bit(clipboardProcess.readAllStandardError()).trimmed();
            reportError(errorText.isEmpty()
                            ? QStringLiteral("Clipboard paste command failed.")
                            : QStringLiteral("Clipboard paste command failed: %1").arg(errorText));
            return;
        }

        const QString clipboardText = QString::fromLocal8Bit(clipboardProcess.readAllStandardOutput());
        const QString normalizedClipboardText = normalizeSourceCode(clipboardText);
        if (normalizedClipboardText.isEmpty()) {
            reportError(QStringLiteral("Clipboard is empty."));
            return;
        }

        appendSource(normalizedClipboardText);
        standardOutput << QStringLiteral("Pasted %1 line%2.")
                              .arg(normalizedClipboardText.count(QLatin1Char('\n')) + 1)
                              .arg(normalizedClipboardText.contains(QLatin1Char('\n')) ? QStringLiteral("s")
                                                                                       : QString())
                       << Qt::endl;
        addHistoryEntry(historyEntry);
    }

    void copyVisibleBufferToClipboard(const QString& historyEntry)
    {
        const QString sourceCode = visibleSourceCode();
        if (sourceCode.isEmpty()) {
            reportError(QStringLiteral("Edit buffer is empty."));
            return;
        }

        const std::optional<ClipboardCommand> command = findClipboardWriteCommand();
        if (!command.has_value()) {
            reportError(QStringLiteral("Cannot find a clipboard copy command."));
            return;
        }

        QProcess clipboardProcess;
        clipboardProcess.start(command->program, command->arguments);
        if (!clipboardProcess.waitForStarted()) {
            reportError(QStringLiteral("Cannot start clipboard copy command: %1").arg(command->program));
            return;
        }

        clipboardProcess.write(sourceCode.toLocal8Bit());
        clipboardProcess.closeWriteChannel();
        if (!clipboardProcess.waitForFinished(3000)) {
            clipboardProcess.kill();
            clipboardProcess.waitForFinished(1000);
            reportError(QStringLiteral("Clipboard copy command timed out."));
            return;
        }
        if (clipboardProcess.exitStatus() != QProcess::NormalExit || clipboardProcess.exitCode() != 0) {
            const QString errorText = QString::fromLocal8Bit(clipboardProcess.readAllStandardError()).trimmed();
            reportError(errorText.isEmpty()
                            ? QStringLiteral("Clipboard copy command failed.")
                            : QStringLiteral("Clipboard copy command failed: %1").arg(errorText));
            return;
        }

        standardOutput << QStringLiteral("Copied %1 line%2.")
                              .arg(sourceCode.count(QLatin1Char('\n')) + 1)
                              .arg(sourceCode.contains(QLatin1Char('\n')) ? QStringLiteral("s") : QString())
                       << Qt::endl;
        addHistoryEntry(historyEntry);
    }

    void addRegisteredSourceFile(const QString& filePathArgument, const QString& historyEntry)
    {
        const QString filePath = filePathArgument.trimmed();
        if (filePath.isEmpty()) {
            reportError(QStringLiteral(".add requires a file path."));
            return;
        }

        const QFileInfo fileInfo(filePath);
        if (!fileInfo.exists() || !fileInfo.isFile()) {
            reportError(QStringLiteral("%1: File not found.").arg(filePath));
            return;
        }

        const QString absoluteFilePath = fileInfo.absoluteFilePath();
        if (registeredSourceFilePaths.contains(absoluteFilePath)) {
            standardOutput << QStringLiteral("Already registered: %1").arg(absoluteFilePath) << Qt::endl;
            addHistoryEntry(historyEntry);
            return;
        }

        registeredSourceFilePaths.append(absoluteFilePath);
        standardOutput << QStringLiteral("Added: %1").arg(absoluteFilePath) << Qt::endl;
        addHistoryEntry(historyEntry);
    }

    void dropRegisteredSourceFile(const QString& filePathOrNumber, const QString& historyEntry)
    {
        const QString target = filePathOrNumber.trimmed();
        if (target.isEmpty()) {
            reportError(QStringLiteral(".drop requires a file path or number."));
            return;
        }

        bool isNumber = false;
        const int fileNumber = target.toInt(&isNumber);
        int index = -1;
        if (isNumber) {
            if (fileNumber <= 0 || fileNumber > registeredSourceFilePaths.size()) {
                reportError(QStringLiteral(".drop number is out of range."));
                return;
            }
            index = fileNumber - 1;
        } else {
            const QString absoluteFilePath = QFileInfo(target).absoluteFilePath();
            index = registeredSourceFilePaths.indexOf(absoluteFilePath);
            if (index < 0) {
                reportError(QStringLiteral("File is not registered: %1").arg(target));
                return;
            }
        }

        const QString removedFilePath = registeredSourceFilePaths.takeAt(index);
        standardOutput << QStringLiteral("Dropped: %1").arg(removedFilePath) << Qt::endl;
        addHistoryEntry(historyEntry);
    }

    void clearRegisteredSourceFiles()
    {
        if (registeredSourceFilePaths.isEmpty()) {
            standardOutput << QStringLiteral("No registered files.") << Qt::endl;
            return;
        }

        registeredSourceFilePaths.clear();
        standardOutput << QStringLiteral("Registered files cleared.") << Qt::endl;
    }

    void openFileIntoVisibleBuffer(const QString& filePath, const QString& historyEntry)
    {
        if (filePath.isEmpty()) {
            reportError(QStringLiteral(".open requires a file path."));
            return;
        }

        const std::optional<QString> sourceCode = readTextFile(filePath);
        if (!sourceCode.has_value()) {
            return;
        }

        replaceVisibleSourceCode(*sourceCode);
        rememberedVisibleBufferFilePath = QFileInfo(filePath).absoluteFilePath();
        lastSavedVisibleSourceCode = visibleSourceCode();
        standardOutput << QStringLiteral("Opened: %1").arg(QFileInfo(filePath).fileName()) << Qt::endl;
        addHistoryEntry(historyEntry);
    }

    void loadAndEvaluateFile(const QString& filePath, const QString& historyEntry)
    {
        if (filePath.isEmpty()) {
            reportError(QStringLiteral(".load requires a file path."));
            return;
        }

        const std::optional<QString> sourceCode = readTextFile(filePath);
        if (!sourceCode.has_value()) {
            return;
        }

        const bool wasVisibleBufferEmpty = visibleSourceCode().isEmpty();
        appendSource(*sourceCode);
        if (interpreter.sendSource(*sourceCode)) {
            rememberedVisibleBufferFilePath = QFileInfo(filePath).absoluteFilePath();
            if (wasVisibleBufferEmpty) {
                lastSavedVisibleSourceCode = visibleSourceCode();
            }
            standardOutput << QStringLiteral("Loaded: %1").arg(QFileInfo(filePath).fileName())
                           << Qt::endl;
            addHistoryEntry(historyEntry);
        }
    }

    void saveVisibleBuffer(const QString& filePathArgument, const QString& historyEntry)
    {
        const QString sourceCodeToWrite = visibleSourceCode();
        if (sourceCodeToWrite.isEmpty()) {
            reportError(QStringLiteral("Edit buffer is empty."));
            return;
        }

        QString filePath = filePathArgument.trimmed();
        if (filePath.isEmpty()) {
            filePath = rememberedVisibleBufferFilePath;
        }
        if (filePath.isEmpty()) {
            reportError(QStringLiteral(".save requires a file path the first time."));
            return;
        }

        if (!writeTextFile(filePath, sourceCodeToWrite)) {
            return;
        }

        rememberedVisibleBufferFilePath = QFileInfo(filePath).absoluteFilePath();
        lastSavedVisibleSourceCode = sourceCodeToWrite;
        standardOutput << QStringLiteral("Saved: %1").arg(QFileInfo(filePath).fileName()) << Qt::endl;
        addHistoryEntry(historyEntry.isEmpty() ? QStringLiteral(".save %1").arg(filePath) : historyEntry);
    }

    void openEditor(const QString& historyEntry)
    {
        QTemporaryFile temporaryFile(QDir::tempPath() + QStringLiteral("/icpp_XXXXXX.cpp"));
        if (!temporaryFile.open()) {
            reportError(QStringLiteral("Cannot open a temporary file."));
            return;
        }

        QTextStream outputStream(&temporaryFile);
        outputStream << visibleSourceCode();
        if (!visibleSourceCode().isEmpty()) {
            outputStream << Qt::endl;
        }
        outputStream.flush();

        const QString temporaryFilePath = temporaryFile.fileName();
        temporaryFile.close();

        const QString editorCommand = determineEditorCommand();
        QStringList editorCommandParts = QProcess::splitCommand(editorCommand);
        if (editorCommandParts.isEmpty()) {
            reportError(QStringLiteral("Cannot determine the editor command."));
            return;
        }

        const QString editorProgram = editorCommandParts.takeFirst();
        editorCommandParts.append(temporaryFilePath);

        QProcess editorProcess;
        editorProcess.setInputChannelMode(QProcess::ForwardedInputChannel);
        editorProcess.setProcessChannelMode(QProcess::ForwardedChannels);
        editorProcess.start(editorProgram, editorCommandParts);

        if (!editorProcess.waitForStarted()) {
            reportError(QStringLiteral("Cannot start the editor: %1").arg(editorProgram));
            return;
        }
        editorProcess.waitForFinished(-1);

        const std::optional<QString> editedSourceCode = readTextFile(temporaryFilePath);
        if (!editedSourceCode.has_value()) {
            reportError(QStringLiteral("Cannot open the edited temporary file."));
            return;
        }

        replaceVisibleSourceCode(*editedSourceCode);
        runVisibleSourceCode();
        addHistoryEntry(historyEntry);
    }

    QString determineEditorCommand() const
    {
        QString editorCommand = qEnvironmentVariable("ICPP_EDITOR");
        if (editorCommand.isEmpty()) {
            editorCommand = qEnvironmentVariable("VISUAL");
        }
        if (editorCommand.isEmpty()) {
            editorCommand = qEnvironmentVariable("EDITOR");
        }
        if (editorCommand.isEmpty()) {
            editorCommand = QString::fromLatin1(kDefaultEditor);
        }
        return editorCommand;
    }

    void loadLibrary(const QString& path, const QString& historyEntry)
    {
        if (path.isEmpty()) {
            reportError(QStringLiteral(".loadlib requires a library path."));
            return;
        }

        const QString pragma = QStringLiteral("#pragma cling load(\"%1\")").arg(quoteForPragma(path));
        appendSource(pragma);
        interpreter.sendSource(pragma);
        addHistoryEntry(historyEntry);
    }

    void includeHeader(const QString& header, const QString& historyEntry)
    {
        if (header.isEmpty()) {
            reportError(QStringLiteral(".include requires a header name."));
            return;
        }

        QString includeDirective;
        if (header.startsWith(QLatin1Char('<')) || header.startsWith(QLatin1Char('"'))) {
            includeDirective = QStringLiteral("#include %1").arg(header);
        } else {
            includeDirective = QStringLiteral("#include <%1>").arg(header);
        }

        appendSource(includeDirective);
        interpreter.sendSource(includeDirective);
        addHistoryEntry(historyEntry);
    }

    void sendPragma(const QString& argument, const QString& historyEntry)
    {
        if (argument.isEmpty()) {
            reportError(QStringLiteral(".pragma requires an argument."));
            return;
        }

        const QString pragma = QStringLiteral("#pragma cling %1").arg(argument);
        appendSource(pragma);
        interpreter.sendSource(pragma);
        addHistoryEntry(historyEntry);
    }

    void printExpression(const QString& expression, const QString& historyEntry)
    {
        if (expression.trimmed().isEmpty()) {
            reportError(QStringLiteral(".print requires an expression."));
            return;
        }

        QString sourceCode;
        if (currentEngine == Engine::QtCling) {
            sourceCode = QStringLiteral("#include <QDebug>\nqDebug().noquote() << (%1);")
                             .arg(expression);
        } else {
            sourceCode = QStringLiteral("#include <iostream>\nstd::cout << (%1) << std::endl;")
                             .arg(expression);
        }

        interpreter.sendSource(sourceCode);
        addHistoryEntry(historyEntry);
    }

    void printExpressionType(const QString& expression, const QString& historyEntry)
    {
        if (expression.trimmed().isEmpty()) {
            reportError(QStringLiteral(".ptype requires an expression."));
            return;
        }

        QString sourceCode;
        if (currentEngine == Engine::QtCling) {
            sourceCode = QStringLiteral(R"(#include <QDebug>
#include <QMetaType>
#include <type_traits>
#include <typeinfo>
([]() {
    using IcppType = std::remove_cv_t<std::remove_reference_t<decltype((%1))>>;
    const char* typeName = QMetaType::fromType<IcppType>().name();
    qDebug().noquote() << (typeName ? typeName : typeid(IcppType).name());
})();)")
                             .arg(expression);
        } else {
            sourceCode = QStringLiteral(R"(#include <iostream>
#include <type_traits>
#include <typeinfo>
([]() {
    using IcppType = std::remove_cv_t<std::remove_reference_t<decltype((%1))>>;
    std::cout << typeid(IcppType).name() << std::endl;
})();)")
                             .arg(expression);
        }

        interpreter.sendSource(sourceCode);
        addHistoryEntry(historyEntry);
    }

    void showWidgets(const QString& historyEntry)
    {
        if (!requireQtClingCommand(QStringLiteral(".widgets"))) {
            return;
        }

        interpreter.sendSource(QStringLiteral(R"(#include <QApplication>
#include <QDebug>
#include <QWidget>
([]() {
    const QWidgetList widgets = QApplication::topLevelWidgets();
    if (widgets.isEmpty()) {
        qDebug().noquote() << "No top-level widgets.";
        return;
    }

    for (QWidget* widget : widgets) {
        qDebug().noquote()
            << QString("0x%1 %2 \"%3\" visible=%4")
                   .arg(reinterpret_cast<quintptr>(widget), 0, 16)
                   .arg(widget->metaObject()->className())
                   .arg(widget->windowTitle())
                   .arg(widget->isVisible() ? "true" : "false");
    }
})();)"));
        addHistoryEntry(historyEntry);
    }

    void closeAllWidgets(const QString& historyEntry)
    {
        if (!requireQtClingCommand(QStringLiteral(".closeall"))) {
            return;
        }

        interpreter.sendSource(QStringLiteral(R"(#include <QApplication>
#include <QDebug>
#include <QWidget>
([]() {
    const QWidgetList widgets = QApplication::topLevelWidgets();
    int closedCount = 0;
    for (QWidget* widget : widgets) {
        if (widget) {
            widget->close();
            ++closedCount;
        }
    }
    qDebug().noquote() << QString("Closed %1 widget%2.")
                              .arg(closedCount)
                              .arg(closedCount == 1 ? "" : "s");
})();)"));
        addHistoryEntry(historyEntry);
    }

    bool requireQtClingCommand(const QString& commandName)
    {
        if (currentEngine == Engine::QtCling) {
            return true;
        }

        reportError(QStringLiteral("%1 requires --engine qtcling.").arg(commandName));
        return false;
    }

    void showRecentErrors()
    {
        if (recentErrors.isEmpty()) {
            standardOutput << QStringLiteral("No icpp command errors recorded. Interpreter diagnostics are forwarded directly.")
                           << Qt::endl;
            return;
        }

        for (const QString& errorMessage : recentErrors) {
            standardOutput << errorMessage << Qt::endl;
        }
    }

    void reportError(const QString& errorMessage)
    {
        recentErrors.append(errorMessage);
        while (recentErrors.size() > 20) {
            recentErrors.removeFirst();
        }
        standardError << errorMessage << Qt::endl;
    }

    bool visibleBufferHasUnsavedChanges() const
    {
        const QString sourceCode = visibleSourceCode();
        return !sourceCode.isEmpty() && sourceCode != lastSavedVisibleSourceCode;
    }

    bool confirmQuitIfVisibleBufferHasUnsavedChanges()
    {
        if (!visibleBufferHasUnsavedChanges()) {
            return true;
        }

        while (true) {
            standardError << QStringLiteral("Warning: edit buffer has unsaved changes. Quit without saving? [Y/N] ")
                          << Qt::flush;
            const std::optional<QString> answer = readConsoleLine(QString());
            if (!answer.has_value()) {
                standardError << Qt::endl;
                return false;
            }

            const QString normalizedAnswer = answer->trimmed().toLower();
            if (normalizedAnswer == QStringLiteral("y") || normalizedAnswer == QStringLiteral("yes")) {
                return true;
            }
            if (normalizedAnswer.isEmpty() || normalizedAnswer == QStringLiteral("n")
                || normalizedAnswer == QStringLiteral("no")) {
                return false;
            }

            standardError << QStringLiteral("Please answer Y or N.") << Qt::endl;
        }
    }

    void addHistoryEntry(const QString& historyEntry)
    {
        if (historyEntry.trimmed().isEmpty()) {
            return;
        }

#if defined(HAVE_READLINE)
        ::add_history(historyEntry.toLocal8Bit().constData());
#else
        Q_UNUSED(historyEntry);
#endif
    }

    Engine currentEngine;
    InterpreterProcess interpreter;
    QTextStream& standardOutput;
    QTextStream& standardError;
    QStringList committedSourceCode;
    QStringList registeredSourceFilePaths;
    QStringList recentErrors;
    QString rememberedVisibleBufferFilePath;
    QString lastSavedVisibleSourceCode;
    bool shouldQuit = false;
};

} // namespace

namespace icpp {

class ReplSession::Impl : public ReplSessionImpl
{
public:
    using ReplSessionImpl::ReplSessionImpl;
};

QString engineName(Engine engine)
{
    return engine == Engine::Cling ? QStringLiteral("cling") : QStringLiteral("qtcling");
}

std::optional<Engine> parseEngineName(const QString& value)
{
    const QString normalized = value.trimmed().toLower();
    if (normalized == QStringLiteral("cling")) {
        return Engine::Cling;
    }
    if (normalized.isEmpty() || normalized == QStringLiteral("qtcling")) {
        return Engine::QtCling;
    }
    return std::nullopt;
}

QString resolveInterpreterProgram(Engine engine,
                                  const QString& commandLinePath,
                                  QTextStream& errorStream)
{
    return resolveInterpreterProgramImpl(engine, commandLinePath, errorStream);
}

ReplSession::ReplSession(Engine engine,
                         QString programPath,
                         QStringList interpreterArguments,
                         QTextStream& output,
                         QTextStream& error)
    : impl(std::make_unique<Impl>(engine,
                                  std::move(programPath),
                                  std::move(interpreterArguments),
                                  output,
                                  error))
{
}

ReplSession::~ReplSession() = default;

ReplSession::ReplSession(ReplSession&&) noexcept = default;

ReplSession& ReplSession::operator=(ReplSession&&) noexcept = default;

int ReplSession::run()
{
    return impl->run();
}

} // namespace icpp
