#include "icpp/repl.h"

#include <QCommandLineOption>
#include <QCommandLineParser>
#include <QCoreApplication>
#include <QTextStream>

namespace {

QTextStream& standardOutput()
{
    static QTextStream stream(stdout);
    return stream;
}

QTextStream& standardError()
{
    static QTextStream stream(stderr);
    return stream;
}

QStringList parseRepeatedOptionValues(const QCommandLineParser& parser,
                                      const QCommandLineOption& option)
{
    return parser.values(option);
}

} // namespace

int main(int argc, char* argv[])
{
    QCoreApplication application(argc, argv);
    QCoreApplication::setApplicationName(QStringLiteral("icpp"));
    QCoreApplication::setApplicationVersion(QStringLiteral("0.2.0"));

    QCommandLineParser commandLineParser;
    commandLineParser.setApplicationDescription(
        QStringLiteral("Interactive C++ REPL wrapper for cling and qtcling."));
    commandLineParser.addHelpOption();
    commandLineParser.addVersionOption();

    const QCommandLineOption engineOption(QStringList() << QStringLiteral("engine"),
                                          QStringLiteral("Select the interpreter engine: cling or qtcling."),
                                          QStringLiteral("engine"),
                                          QStringLiteral("qtcling"));
    const QCommandLineOption clingOption(QStringList() << QStringLiteral("cling"),
                                         QStringLiteral("Path to the cling executable."),
                                         QStringLiteral("path"));
    const QCommandLineOption qtClingOption(QStringList() << QStringLiteral("qtcling"),
                                           QStringLiteral("Path to the qtcling executable."),
                                           QStringLiteral("path"));
    const QCommandLineOption interpreterArgumentOption(
        QStringList() << QStringLiteral("interpreter-arg"),
        QStringLiteral("Additional argument passed to the selected interpreter."),
        QStringLiteral("arg"));
    const QCommandLineOption clingArgumentOption(
        QStringList() << QStringLiteral("cling-arg"),
        QStringLiteral("Additional argument passed to cling when --engine cling is selected."),
        QStringLiteral("arg"));
    const QCommandLineOption qtClingArgumentOption(
        QStringList() << QStringLiteral("qtcling-arg"),
        QStringLiteral("Additional argument passed to qtcling when --engine qtcling is selected."),
        QStringLiteral("arg"));

    commandLineParser.addOption(engineOption);
    commandLineParser.addOption(clingOption);
    commandLineParser.addOption(qtClingOption);
    commandLineParser.addOption(interpreterArgumentOption);
    commandLineParser.addOption(clingArgumentOption);
    commandLineParser.addOption(qtClingArgumentOption);
    commandLineParser.process(application);

    const std::optional<icpp::Engine> parsedEngine =
        icpp::parseEngineName(commandLineParser.value(engineOption));
    if (!parsedEngine.has_value()) {
        standardError() << QStringLiteral("Invalid value for --engine. Use 'cling' or 'qtcling'.")
                        << Qt::endl;
        return 1;
    }

    const QString explicitProgram = *parsedEngine == icpp::Engine::Cling
        ? commandLineParser.value(clingOption)
        : commandLineParser.value(qtClingOption);
    const QString interpreterProgram =
        icpp::resolveInterpreterProgram(*parsedEngine, explicitProgram, standardError());
    if (interpreterProgram.isEmpty()) {
        return 1;
    }

    QStringList interpreterArguments =
        parseRepeatedOptionValues(commandLineParser, interpreterArgumentOption);
    interpreterArguments.append(parseRepeatedOptionValues(
        commandLineParser,
        *parsedEngine == icpp::Engine::Cling ? clingArgumentOption : qtClingArgumentOption));

    icpp::ReplSession replSession(*parsedEngine,
                                  interpreterProgram,
                                  interpreterArguments,
                                  standardOutput(),
                                  standardError());
    return replSession.run();
}
