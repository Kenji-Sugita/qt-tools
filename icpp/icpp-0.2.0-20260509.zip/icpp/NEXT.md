# NEXT

## 次にやること

- コミットする場合は、`icpp` 関連ファイルだけを stage する。
- リリース ZIP は `icpp-0.2.0-20260509.zip` が最新。
  - ZIP 内トップは `icpp/`。
  - ZIP 内 PDF の表紙が `cling / qtcling 対応 C++ REPL` と `Version 0.2.0` になっていることは確認済み。
  - `USER_GUIDE.md` / `USER_GUIDE.pdf` の Cling dot command 説明も反映済み。
- 複数ファイル機能とクリップボード機能は実装済み。次に触る場合は `USER_GUIDE.md` と `.help` の説明が仕様とずれていないか確認する。
- 残りの大きな作業として、Qt Creator プラグイン化を検討する。
  - `icpp` と同じ interpreter 管理の仕組みで、選択範囲や現在ファイルを `qtcling` に送る。
  - `qDebug()` / Qt message handler の出力は Qt Creator の Output Pane に流す。
  - `InterpreterProcess` 相当は `src/repl.cpp` 側に分離済み。次は CLI とプラグインで共有しやすい API に整理する。

## 未完了

- `icpp` 本体は実装済み。
- バージョンは `0.2.0`。
- `USER_GUIDE.md` / `USER_GUIDE.pdf` は作成済み。
- `README.md` / `CHANGELOG.md` は作成済み。
- `.p` / `.print` は実装済み。
- `.errors` / `.ptype` / `.widgets` / `.closeall` は実装済み。
- デフォルトエンジンは `qtcling` に変更済み。
- `QPushButton` の例は `examples/08_push_button.cpp` に REPL 用 `go()` として追加済み。
- 未保存の編集バッファがある状態で `.q` / `.quit` した場合は `[Y/N]` で確認するように実装済み。
- `.add` / `.files` / `.drop` / `.clearfiles` による複数ファイル管理を実装済み。
- `.r` / `.run` は、interpreter を restart してから登録ファイルを順番に評価し、最後に編集バッファを評価する。
- `.paste` / `.copy` による外部コマンド経由のクリップボード連携を実装済み。
- Qt Creator プラグインは未着手。

## 今回完了

- `qDebug()` など interpreter 側の遅延出力が、`.q` まで表示されない問題を修正済み。
- interpreter の stdout/stderr は `QProcess::ForwardedChannels` で親プロセスへ直接流す。
- 非対話入力では、入力が `.q` まで先行しすぎないよう送信後の短い待ちを残す。
- `main.cpp` を `src/main.cpp` に移動した。
- `ReplSession` などの REPL 実装を `include/icpp/repl.h` と `src/repl.cpp` に切り出した。
- `examples/` に GitHub Copilot 向け日本語コメント付きサンプルを 10 個追加した。
- `USER_GUIDE.md` を `genpdf` 向けに調整し、`!toc`、`!callout`、Mermaid 図、同梱サンプル一覧を追加した。
- `USER_GUIDE.pdf` を `genpdf` で再生成した。
- 配布用 ZIP `icpp-release-20260509.zip` を作成した。ZIP 内トップは `icpp/`。
- `.q` / `.quit` 時に未保存の編集バッファがあれば、`Quit without saving? [Y/N]` と確認するようにした。
  - `Y` / `yes`: 終了する。
  - `N` / `no` / Enter: 終了せず REPL に戻る。
  - 保存済み、`.discard` 済み、`.reset` 済み、空バッファでは確認しない。
- 複数ファイル機能を追加した。
  - `.add <file>`: `.r` で評価するファイルを登録する。
  - `.files`: 登録ファイル一覧を表示する。
  - `.drop <file|number>`: 登録ファイルを外す。
  - `.clearfiles`: 登録ファイルを全て外す。
- `.r` は登録ファイルと編集バッファをまとめて再評価する仕様に拡張した。
- `.copy` / `.paste` を追加した。
  - `QClipboard` ではなく、`pbcopy` / `pbpaste` などの外部コマンドを使う。
  - `ICPP_CLIPBOARD_COPY` / `ICPP_CLIPBOARD_PASTE` でコマンドを明示できる。
- `USER_GUIDE.md` に `.r` / `.add` / `.paste` の作業モデル、複数ファイル例、Copilot との連携例を追記した。
- `USER_GUIDE.md` に `.errors` / `.ptype` / `.widgets` / `.closeall` の詳細説明を追記した。
- 社内向け `0.2.0` リリース用に `README.md` と `CHANGELOG.md` を追加した。
- `USER_GUIDE.pdf` はページ番号付きで再生成済み。
- `USER_GUIDE.md` の front matter は `subtitle` と `version: 0.2.0` を分けて指定する形に修正済み。
- `icpp-0.2.0-20260509.zip` は、最新の `USER_GUIDE.md` / `USER_GUIDE.pdf` / `NEXT.md` を含むよう再作成済み。

## 触るファイル

- `src/main.cpp`
- `src/repl.cpp`
- `include/icpp/repl.h`
- `CMakeLists.txt`
- `tests/run_tests.sh`
- `NEXT.md`
- `README.md`
- `CHANGELOG.md`
- `USER_GUIDE.md`
- `USER_GUIDE.pdf`
- `examples/*.cpp`
- `icpp-0.2.0-20260509.zip`

## 注意

- リポジトリ root は `/Users/sugita/src`。
- repo 全体には無関係な未追跡ファイルや変更が多いので、`git add .` は避ける。
- 今回のコミット対象候補:
  - `tools/icpp/CMakeLists.txt`
  - `tools/icpp/src/main.cpp`
  - `tools/icpp/src/repl.cpp`
  - `tools/icpp/include/icpp/repl.h`
  - `tools/icpp/tests/run_tests.sh`
  - `tools/icpp/examples/*.cpp`
  - `tools/icpp/USER_GUIDE.md`
  - `tools/icpp/USER_GUIDE.pdf`
  - `tools/icpp/icpp-0.2.0-20260509.zip`
  - `tools/icpp/NEXT.md`
- `tools/icpp/main.cpp` は削除済み。新しい main は `tools/icpp/src/main.cpp`。
- `build/`, `button.cpp`, `concat.cpp`, `leap.cpp`, `quit.cpp` は作業中サンプル/生成物なので、通常はコミットしない。
- `RELEASE_ANNOUNCEMENT_0.2.0.txt` は社内案内文の作業ファイルで、配布 ZIP 対象外。
- `icpp-release-20260509.zip` は不要な旧名 ZIP として削除済み。
- 未保存確認のテストは `tests/run_tests.sh` に追加済み。
- 複数ファイル機能とクリップボード機能のテストは `tests/run_tests.sh` に追加済み。
- `CMakeLists.txt` を触る前には `~/AGENTS.cmake.md` を読む指示がある。今回は読了済み。
- テストは以下で通過済み:
  - `cmake --build build`
  - `ctest --test-dir build --output-on-failure`
- 追加確認:
  - TTY 上で `QTimer::singleShot()` から後で出る `qDebug()` が `.q` なしで表示されることを確認済み。
- `ctest` は `qtcling` 起動分で 10 秒を超えるため、`icpp_integration` に `TIMEOUT 60` を設定済み。
- `qtcling` は PATH 上の `/usr/local/src/cling/bin/qtcling` を使う想定。
- `cling` は `/usr/local/src/cling/build/bin/cling` を既定 fallback にしている。
- `icpp` の既定エンジンは `qtcling`。`cling` を使う場合は `--engine cling`。
