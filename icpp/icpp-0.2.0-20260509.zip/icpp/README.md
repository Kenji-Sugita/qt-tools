# icpp

`icpp` is a small REPL wrapper for `cling` and `qtcling`.

It does not interpret C++ by itself. It starts `cling` or `qtcling` as the
interpreter process and adds workflow-oriented commands for editing, rerunning,
multi-file experiments, value inspection, and clipboard exchange.

## Version

Current release: `0.2.0`

## Requirements

- macOS
- Qt 6
- CMake 3.16 or later
- A working `cling` or `qtcling`

The default engine is `qtcling`. The usual internal paths are:

```text
/usr/local/src/cling/bin/qtcling
/usr/local/src/cling/build/bin/cling
```

You can override them with command line options or environment variables.

```text
icpp --engine qtcling --qtcling /path/to/qtcling
icpp --engine cling --cling /path/to/cling
```

```text
ICPP_QTCLING=/path/to/qtcling
ICPP_CLING=/path/to/cling
```

## Build

```text
cmake -S . -B build
cmake --build build
```

Run:

```text
./build/icpp
```

Check the version:

```text
./build/icpp --version
```

## Typical Workflow

Use `icpp` as a lightweight workbench for Qt/C++ experiments.

```text
icpp[qtcling]> .e
icpp[qtcling]> .r
icpp[qtcling]> .p value
icpp[qtcling]> .ptype value
```

For several source files:

```text
icpp[qtcling]> .add SimpleClass.cpp
icpp[qtcling]> .add UseSimpleClass.cpp
icpp[qtcling]> .r
```

For clipboard exchange with an editor or GitHub Copilot:

```text
icpp[qtcling]> .paste
icpp[qtcling]> .r
icpp[qtcling]> .copy
```

## Main Commands

```text
.e / .edit              edit the current buffer
.r / .run               restart and evaluate registered files, then buffer
.add <file>             add a file evaluated by .r
.files                  show registered files
.drop <file|number>     remove a registered file
.p <expr>               print an expression
.ptype <expr>           show the expression type
.paste                  append clipboard text to the buffer
.copy                   copy the buffer to the clipboard
.widgets                show top-level QWidget objects
.closeall               close top-level QWidget objects
```

See `USER_GUIDE.pdf` for the full guide.
