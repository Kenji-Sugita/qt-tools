#include <QApplication>
#include <QCoreApplication>
#include <QEventLoop>

extern "C" void cling_set_periodic_callback(void (*callback)(), int interval_ms);
extern "C" void cling_clear_periodic_callback();

namespace {
int applicationArgumentCount = 1;
char applicationName[] = "cling";
char* applicationArgumentValues[] = { applicationName, nullptr };
QApplication* applicationInstance = nullptr;
}

QApplication* ensureApplication()
{
    if (QCoreApplication::instance() != nullptr) {
        return static_cast<QApplication*>(QCoreApplication::instance());
    }

    if (applicationInstance == nullptr) {
        applicationInstance =
            new QApplication(applicationArgumentCount, applicationArgumentValues);
    }

    return applicationInstance;
}

void processQtEventsPeriodically()
{
    if (QCoreApplication::instance() == nullptr) {
        return;
    }

    QCoreApplication::processEvents(QEventLoop::AllEvents, 5);
}

void enablePeriodicQtEvents()
{
    ensureApplication();
    cling_set_periodic_callback(&processQtEventsPeriodically, 50);
}

void disablePeriodicQtEvents()
{
    cling_clear_periodic_callback();
}
