---
genpdf:
  format: book
  title: qtcling 1.1.0 利用者ガイド
  author: (株) SRA
  font_size: 12pt
  page_numbers: true
  copyright: Copyright (c) 2026 SRA, Inc. All rights reserved.
  table:
    header_background: "#e8f1ff"
    header_color: "#1f2937"
    border_color: "#cbd5e1"
    border_width: "1px"
    stripe: true
    stripe_background: "#f8fafc"
    cell_padding: "0.45em 0.65em"
    font_size: "0.95em"
    compact: false
    align: left
    header_align: center
    cell_align: left
---

# qtcling 1.1.0 利用者ガイド

## qtcling とは

qtcling は、Cling の C++ REPL から Qt を対話的に使うための環境です。

通常のビルドを待たずに、REPL で Qt object や widget を作り、表示し、signal/slot や property の動きを確認することを目的にしています。

## 現在の位置づけ

1.1.0 は source code release です。

1.1.0 のユーザー向け対象は、端末版 `qtcling` interactive です。

1.1.0 では、clean build 時の patch 適用問題に加え、qtcling launcher / wrapper / defaults / `src/qtgui.cpp` の install workflow を修正しています。

macOS では、端末版 `qtcling` で QtCore / QtGui / QtWidgets と event callback が使えることを確認しています。

Linux では、端末版 `qtcling` の `--show-config` / `--check` と、Qt application の初期化を確認しています。

Windows は native Windows 版ではなく、Windows 11 の WSL2 + WSLg 上で Linux 版 `qtcling` を使う方針です。WSL2 / WSLg でも build と GUI 表示を確認しています。

`qtcling-gui`, `qtcling-project`, `qtcling.toml`, `moc` / `uic` / `rcc` 自動生成構想、Qt Creator plugin 構想、Windows native wrapper は 1.1.0 のユーザー向け対象外です。

## macOS クイックスタート

確認済みの基本環境変数です。

```sh
export QTCLING_QT_ROOT=/usr/local/qt/Qt/6.11.1/macos
export QTCLING_CLING_ROOT="$PWD/build"
export QTCLING_STARTUP_FILE="$PWD/src/qtgui.cpp"
```

`/usr/local/qtcling` に hook 入り Cling をまだ install していない場合は、`QTCLING_CLING_ROOT="$PWD/build"` を指定してください。

端末版を起動します。

```sh
qtcling
```

起動後、`qApp` が使えることを確認します。

```cpp
qApp
```

widget を作って表示します。

```cpp
#include <QPushButton>
auto button = new QPushButton("OK?");
button->show()
```

## source code release zip から使う

配布 zip は source code release です。`build/`、`cling/`、`llvm-project/`、インストール済み Qt は含めていません。

展開します。

```sh
unzip qtcling-1.1.0-source.zip
cd qtcling-1.1.0
```

## インストール手順

`qtcling` を使うには、Qt のほかに、interactive patch を適用した Cling が必要です。

### 依存 library

Qt の既定 installation path は [`bin/qtcling-defaults.sh`](bin/qtcling-defaults.sh) で指定できます。
build 前に `QTCLING_DEFAULT_QT_ROOT` の値を Qt kit の完全な path へ変更してください。

```sh
QTCLING_DEFAULT_QT_ROOT=${QTCLING_DEFAULT_QT_ROOT:-/usr/local/qt/Qt/6.11.1/macos}
./build.sh
```

この設定は build と起動 wrapper の両方で読み込まれます。`QTCLING_QT_ROOT` は個別起動用の
完全な kit path で、`QTCLING_DEFAULT_QT_ROOT` より優先されます。

Linux / WSL では、REPL 入力待ち中に Qt event を処理するため、LLVM の libedit LineEditor support が必要です。Ubuntu / WSL では build 前に `libedit-dev` を入れてください。

```sh
sudo apt install libedit-dev
```

`libedit-dev` がない場合、build は進むことがありますが、REPL 入力待ち中に Qt event が処理されず、button click などが Enter 後にまとめて反応することがあります。`build.sh` は `LLVM_ENABLE_LIBEDIT=OFF` を検出すると警告します。

macOS では Xcode SDK に含まれる libedit を使います。

`libzstd` は任意です。qtcling interactive の通常利用には必要ありません。LLVM/CMake が環境にある zstd を見つける場合がありますが、zstd support の有無は通常の Qt REPL 利用には影響しません。

配布物の `build.sh` は次を行います。

1. `cling/` がなければ `root-project/cling` の `v1.3` を clone する。
2. `llvm-project/` がなければ `root-project/llvm-project` の `cling-latest` を clone する。
3. `patch/qtcling-interactive/` の必須パッチを適用する。
4. `build/` で Cling を build する。
5. `/usr/local/qtcling` に install する。

必須パッチが適用できず、既に適用済みでもない場合、`build.sh` はそこで停止します。

実行例:

```sh
./build.sh
```

`/usr/local/qtcling` に書き込むため、環境によっては install 段階で権限が必要です。

### install して使う

`build.sh` の最後まで成功すると、Cling は `/usr/local/qtcling` に install されます。

この場合、macOS wrapper は既定で `/usr/local/qtcling/bin/cling` を使うため、`QTCLING_CLING_ROOT` は通常不要です。

macOS では Qt root を指定して確認します。

```sh
export QTCLING_QT_ROOT=/usr/local/qt/Qt/6.11.1/macos
bin/qtcling --check
bin/qtcling --show-config
bin/qtcling
```

### install せず build tree のまま使う

`/usr/local/qtcling` に install しない場合は、build tree を `QTCLING_CLING_ROOT` で指定します。

```sh
export QTCLING_QT_ROOT=/usr/local/qt/Qt/6.11.1/macos
export QTCLING_CLING_ROOT="$PWD/build"
bin/qtcling --check
bin/qtcling --show-config
bin/qtcling
```

`$QTCLING_CLING_ROOT/bin/cling` が使われます。

### 手動で clone / patch / build する

`build.sh` を使わずに手動で進める場合は、次の順に実行します。

```sh
git clone --branch v1.3 https://github.com/root-project/cling.git
git clone --branch cling-latest https://github.com/root-project/llvm-project.git
git apply patch/qtcling-interactive/0001-cling-add-periodic-callback-api.patch
git apply patch/qtcling-interactive/0002-llvm-lineeditor-periodic-callback.patch
git apply patch/qtcling-interactive/0003-cling-load-qtcling-startup-file.patch
git apply patch/qtcling-interactive/0006-warn-when-libedit-is-disabled.patch
mkdir -p build
cd build
cmake -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX=/usr/local/qtcling \
  -DLLVM_ENABLE_PROJECTS=clang \
  -DLLVM_EXTERNAL_PROJECTS=cling \
  -DLLVM_EXTERNAL_CLING_SOURCE_DIR=../cling \
  -DLLVM_BUILD_TOOLS=OFF \
  -DLLVM_TARGETS_TO_BUILD=host \
  ../llvm-project/llvm
cmake --build . -j
```

install する場合:

```sh
cd ..
sudo ./install.sh
```

`install.sh` は CMake が build 時に設定した install prefix へ Cling と qtcling の
launcher、startup file を配置します。既定の install prefix は `/usr/local/qtcling` です。

install せずに使う場合:

```sh
cd ..
export QTCLING_CLING_ROOT="$PWD/build"
```

### startup file

source code release の wrapper は、展開先ディレクトリを自動的に `QTCLING_DEV_ROOT` として扱います。

通常は `QTCLING_STARTUP_FILE` を明示しなくても、展開先の `src/qtgui.cpp` が使われます。

別の startup file を使う場合だけ指定します。

```sh
export QTCLING_STARTUP_FILE="$PWD/src/qtgui.cpp"
```

## 起動確認

macOS では、まず Qt root を指定します。

```sh
export QTCLING_QT_ROOT=/usr/local/qt/Qt/6.11.1/macos
```

install した場合は、そのまま展開した配布物の `bin/qtcling` を実行できます。

```sh
bin/qtcling --check
bin/qtcling --show-config
bin/qtcling
```

install せず build tree を使う場合は、先に `QTCLING_CLING_ROOT` を指定します。

```sh
export QTCLING_CLING_ROOT="$PWD/build"
bin/qtcling --check
```

必要なら PATH に追加します。

```sh
export PATH="$PWD/bin:$PATH"
```

## Windows 11 / WSL2

Windows では、native Windows 版 `qtcling` ではなく WSL2 + WSLg 上の Linux 版 `qtcling` を使います。

WSL 内の Linux filesystem 側に source tree と build tree を置きます。`/mnt/c/...` 配下での build は遅くなりやすいため避けてください。

```sh
mkdir -p ~/src
cd ~/src
git clone <qtcling-repository-url> qtcling
cd qtcling
```

Qt は Windows 用 kit ではなく、WSL 内の Linux kit を使います。

```sh
export QTCLING_QT_ROOT=/usr/local/qt/Qt/6.11.1/gcc_64
```

通常の Linux と同じように build します。

```sh
./build.sh
```

build tree の Cling を使って確認します。

```sh
export QTCLING_CLING_ROOT="$PWD/build"
./bin/qtcling --show-config
./bin/qtcling --check
```

WSLg の GUI 表示を確認します。

```sh
./bin/qtcling
```

REPL で:

```cpp
qApp
#include <QPushButton>
new QPushButton("OK")->show()
```

GUI 表示なしで先に CLI 側だけ確認する場合は、offscreen platform を使います。

```sh
QT_QPA_PLATFORM=offscreen ./bin/qtcling
```

REPL で:

```cpp
qApp
QCoreApplication::instance()
```

この配布物には次を含めています。

- `bin/qtcling`
- `bin/iqtcling.*` / `bin/cqtcling.*`
- `bin/qtcling-gui`
- `bin/qtcling-project`
- `bin/qtcling_project.py`
- `bin/run_moc`
- `bin/run_uic`
- `bin/run_rcc`
- `bin/run_all`
- `qtcling-gui/`
- `patch/qtcling-interactive.patch`
- `patch/qtcling-interactive/`
- `examples/`
- `src/`

## interactive patch を適用する

`qtcling` の interactive event loop 対応には、`cling/` と `llvm-project/` への patch が必要です。

top-level checkout に `cling/` と `llvm-project/` がある状態で、配布物内の必須パッチを適用します。

```sh
git apply patch/qtcling-interactive/0001-cling-add-periodic-callback-api.patch
git apply patch/qtcling-interactive/0002-llvm-lineeditor-periodic-callback.patch
git apply patch/qtcling-interactive/0003-cling-load-qtcling-startup-file.patch
git apply patch/qtcling-interactive/0006-warn-when-libedit-is-disabled.patch
```

統合パッチ `patch/qtcling-interactive.patch` は、この 4 つの必須パッチだけを連結したものです。

個別に確認したい場合は、`patch/qtcling-interactive/` の patch を参照してください。

- `0001-cling-add-periodic-callback-api.patch`
- `0002-llvm-lineeditor-periodic-callback.patch`
- `0003-cling-load-qtcling-startup-file.patch`
- `0006-warn-when-libedit-is-disabled.patch`

`0004-qtcling-wrapper-macos-linux-fixes.patch` と `0005-linux-wrapper-diagnostics.patch` は top-level wrapper 用の参考パッチです。最新の checkout では top-level wrapper 修正は Git 側に含まれているため、通常は適用しません。

## 端末版 qtcling

`qtcling` は端末上の Cling REPL を使います。

```sh
qtcling
```

macOS interactive 版では、`QTCLING_STARTUP_FILE` により `src/qtgui.cpp` を起動時に読み込みます。そのため、手動で `.L qtgui.cpp` を実行しなくても `QApplication` が準備されます。

examples を読み込む例です。

```cpp
.I examples
.L button.cpp
```

`examples/button.cpp` は button click 時に `OK?` を出力します。REPL 入力待ち中でも Qt event が処理されることを確認できます。

## GUI 版 qtcling-gui

`qtcling-gui` は、Qt GUI アプリ内に REPL 風の入力欄と出力欄を持つ prototype です。

```sh
qtcling-gui
```

端末の `LineEditor` / libedit に依存せず、Qt の `QApplication::exec()` 上で Cling を動かします。

確認例:

```cpp
qApp
#include <QPushButton>
auto button = new QPushButton("OK?");
button->show()
```

現時点では 1 行入力のみです。履歴、補完、複数行入力などは未実装です。

## 環境変数

### `QTCLING_QT_ROOT`

Qt installation root を指定します。

```sh
export QTCLING_QT_ROOT=/usr/local/qt/Qt/6.11.1/macos
```

macOS では、この下の `lib/*.framework` を使って include path と framework path を組み立てます。

### `QTCLING_CLING_ROOT`

使用する Cling の root を指定します。

```sh
export QTCLING_CLING_ROOT="$PWD/build"
```

`$QTCLING_CLING_ROOT/bin/cling` が使われます。

### `QTCLING_STARTUP_FILE`

qtcling 起動時に読み込む startup file を指定します。

```sh
export QTCLING_STARTUP_FILE="$PWD/src/qtgui.cpp"
```

この file が `QApplication` の準備と Qt event processing callback の設定を行います。

### `QTCLING_MODULES`

使用する Qt module を指定します。

```sh
export QTCLING_MODULES="Core Gui Widgets Network"
```

デフォルトは `Core Gui Widgets` です。

例:

```sh
QTCLING_MODULES="Core Gui Widgets Network" qtcling
```

REPL で:

```cpp
#include <QTcpSocket>
auto socket = new QTcpSocket;
socket
```

### `QTCLING_RESOURCE_DIR`

`qtcling-gui` で Clang resource directory を明示する場合に使います。

```sh
export QTCLING_RESOURCE_DIR="$PWD/build/lib/clang/20"
```

通常は build-time default が使われます。

## 設定確認

macOS / Linux interactive 版では、設定確認用 option があります。Windows 11 では WSL2 上で Linux 版として同じ option を使います。

```sh
qtcling --version
qtcling --show-config
qtcling --check
```

`--version` は、配布物 root の `VERSION` file に書かれた qtcling の release version を表示します。

`--show-config` は、Qt root、module、framework path または library path、Cling executable、startup file、Cling args を表示します。

`--check` は、Qt root、Qt libraries、Cling executable、startup file の存在を確認します。

## Qt module を追加する

追加 module を使う場合は `QTCLING_MODULES` を指定します。

```sh
QTCLING_MODULES="Core Gui Widgets Network" qtcling
```

macOS では、指定された module から include path と framework load 設定を生成します。Linux / WSL では、include path、`.so` preload、`-lQt6...` link 引数を生成します。

## qtcling-project

`qtcling-project` は、将来の project helper の最小 prototype です。

現時点では `explain` のみ実装されています。project 単位の自動生成や自動起動はまだ行いません。

```sh
qtcling-project explain examples/wiggly
```

表示する内容:

- project directory
- `qtcling.toml` の有無
- `.pro` の有無
- sources
- headers
- forms
- resources
- translations
- Qt modules
- include dirs
- defines
- autogen outputs
- generated startup includes
- warnings
- unsupported features

例:

```sh
qtcling-project explain examples/widgets/tutorials/notepad
```

plugin project は初期対象外です。検出した場合は `Unsupported` に表示します。

```sh
qtcling-project explain examples/cpp-advanced/solutions/sif
```

## Qt generated files を作る

通常の Qt コードは、`moc` / `uic` / `rcc` が作るファイルに依存します。

たとえば `Q_OBJECT` を含む class は `moc` 出力が必要です。`.ui` を使う code は `ui_*.h` が必要です。`.qrc` を使う code は `qrc_*.cpp` が必要です。これらを生成しないと、ほとんどの Qt example はそのままでは実行できません。

qtcling には手動実行用の helper があります。

```sh
run_moc [files...]
run_uic [files...]
run_rcc [files...]
run_all
```

`run_moc` は、指定した C++ header/source のうち `Q_OBJECT` を含むものだけに `moc` を実行します。

| 入力 | 出力 |
|---|---|
| `widget.h` | `moc_widget.cpp` |
| `widget.cpp` | `widget.moc` |

`run_uic` は `.ui` から `ui_<basename>.h` を作ります。

| 入力 | 出力 |
|---|---|
| `mainwindow.ui` | `ui_mainwindow.h` |

`run_rcc` は `.qrc` から `qrc_<basename>.cpp` を作ります。

| 入力 | 出力 |
|---|---|
| `resources.qrc` | `qrc_resources.cpp` |

引数を省略すると、各 helper はカレントディレクトリの対象ファイルを処理します。

例:

```sh
cd examples/wiggly
run_all
```

`run_all` は、カレントディレクトリで `run_moc`, `run_rcc`, `run_uic` を順に実行します。

```sh
run_all
```

`moc` / `uic` / `rcc` が PATH にない場合は、各 helper に明示できます。

```sh
run_moc --moc /path/to/moc widget.h
run_uic --uic /path/to/uic mainwindow.ui
run_rcc --rcc /path/to/rcc resources.qrc
```

### 翻訳ファイル

`TRANSLATIONS` や `.ts` を使う project では、通常の Qt build と同じく `.qm` が必要になる場合があります。

現時点の qtcling は、`qtcling-project explain` で translations を表示しますが、`lrelease` / `lupdate` / `lconvert` は実行しません。

- `lrelease`: `.ts` から `.qm` を作る処理です。将来の `qtcling-project prepare` では stale な `.qm` 生成対象にします。
- `lupdate`: `.ts` を更新する処理です。ユーザーの翻訳ファイルを書き換えるため、既定では自動実行しません。
- `lconvert`: 翻訳ファイル形式の変換などに使います。現時点では未対応です。

そのため翻訳を使う project では、必要に応じてユーザーが Qt の tool を直接実行してください。

```sh
lrelease *.ts
```

`.qm` を `.qrc` に含めている project では、`.qm` を先に更新してから resource を生成します。

```sh
lrelease *.ts
run_rcc *.qrc
```

または、`.qm` 更新後に通常どおり `run_all` を実行します。

```sh
lrelease *.ts
run_all
```

## examples を動かす

現在の基本形は、必要な generated files を先に作り、対象ディレクトリを include path に追加し、`startup.cpp` を読み込んで `startup()` を呼ぶ方法です。

例:

```sh
cd examples/wiggly
run_all
cd ../..
```

```sh
qtcling
```

REPL で:

```cpp
.I examples/wiggly
.L examples/wiggly/startup.cpp
startup()
```

今後は `qtcling-project prepare` や `qtcling --run .` で、`moc` / `uic` / `rcc` / `startup()` 生成を隠す予定です。

## 現在の制限

- 1.1.0 は source code release です。
- 1.1.0 のユーザー向け対象は端末版 `qtcling` interactive です。
- `qtcling-gui` は prototype であり、1.1.0 のユーザー向け対象外です。
- `qtcling-project` は `explain` のみであり、1.1.0 のユーザー向け対象外です。
- `moc` / `uic` / `rcc` は helper で手動実行できますが、project 単位の自動実行は未実装です。
- `lrelease` / `lupdate` / `lconvert` は未実装です。
- `qtcling.toml` は読み取りの初期対応のみです。
- QML、plugin、deployment、D-Bus、Remote Objects、ShaderTools は初期対象外です。
- plugin project は REPL だけでは通常の Qt plugin として扱えません。

## トラブルシュート

### `qApp` が未定義になる

hook 入り Cling を使っているか確認してください。

```sh
export QTCLING_CLING_ROOT="$PWD/build"
qtcling
```

また、`QTCLING_STARTUP_FILE` が正しいか確認します。

```sh
qtcling --check
```

### `resource directory lib/clang/20 not found` が出る

`qtcling-gui` で Clang resource directory が見つからない状態です。

```sh
export QTCLING_RESOURCE_DIR="$PWD/build/lib/clang/20"
qtcling-gui
```

### Qt module の header が見つからない

`QTCLING_MODULES` に module を追加してください。

```sh
QTCLING_MODULES="Core Gui Widgets Network" qtcling
```

### plugin example が動かない

plugin は初期対象外です。`qtcling-project explain` で unsupported として表示される場合、その example は通常の autogen workflow では扱いません。
