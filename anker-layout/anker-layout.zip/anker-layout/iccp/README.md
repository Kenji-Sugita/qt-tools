# 操作例

```text
icpp[qtcling]> .i include
icpp[qtcling]> .add src/AnkerFormAttachment.cpp
icpp[qtcling]> .add src/AnkerFormLayout.cpp
icpp[qtcling]> .add diagonal.cpp
icpp[qtcling]> .files
1  /Users/sugita/src/qt/tools/anker-layout/src/AnkerFormAttachment.cpp
2  /Users/sugita/src/qt/tools/anker-layout/src/AnkerFormLayout.cpp
3  /Users/sugita/src/qt/tools/anker-layout/diagonal.cpp
icpp[qtcling]> .r
```
