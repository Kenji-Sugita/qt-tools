<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja_JP" sourcelanguage="en_US">
<context>
    <name>ImageExportDialog</name>
    <message>
        <source>Image Export Settings</source>
        <translation>画像保存設定</translation>
    </message>
    <message>
        <source>PNG</source>
        <translation>PNG</translation>
    </message>
    <message>
        <source>SVG</source>
        <translation>SVG</translation>
    </message>
    <message>
        <source>Transparent</source>
        <translation>透明</translation>
    </message>
    <message>
        <source>White</source>
        <translation>白</translation>
    </message>
    <message>
        <source>Background</source>
        <translation>背景</translation>
    </message>
    <message>
        <source>Format:</source>
        <translation>形式:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <source>Import Drawing Data...</source>
        <translation>描画データをインポート...</translation>
    </message>
    <message>
        <source>Export Drawing Data...</source>
        <translation>描画データをエキスポート...</translation>
    </message>
    <message>
        <source>Import Drawing Data</source>
        <translation>描画データをインポート</translation>
    </message>
    <message>
        <source>Export Drawing Data</source>
        <translation>描画データをエキスポート</translation>
    </message>
    <message>
        <source>Whiteboard drawing data (*.whiteboard *.json)</source>
        <translation>ホワイトボード描画データ (*.whiteboard *.json)</translation>
    </message>
    <message>
        <source>Whiteboard drawing data (*.whiteboard)</source>
        <translation>ホワイトボード描画データ (*.whiteboard)</translation>
    </message>
    <message>
        <source>Could Not Import Drawing Data</source>
        <translation>描画データをインポートできませんでした</translation>
    </message>
    <message>
        <source>Could Not Export Drawing Data</source>
        <translation>描画データをエキスポートできませんでした</translation>
    </message>
    <message>
        <source>The drawing data could not be imported.
%1</source>
        <translation>描画データをインポートできませんでした。
%1</translation>
    </message>
    <message>
        <source>The drawing data could not be exported.
%1</source>
        <translation>描画データをエキスポートできませんでした。
%1</translation>
    </message>
    <message>
        <source>Importing %1 pages would exceed the limit of %2 pages.</source>
        <translation>%1 ページを取り込むと、上限の %2 ページを超えます。</translation>
    </message>
    <message>
        <source>Imported %1 pages after the current page. Undo removes this import.</source>
        <translation>現在のページの直後に %1 ページを取り込みました。「元に戻す」で取り込みを取り消せます。</translation>
    </message>
    <message>
        <source>All pages</source>
        <translation>全ページ</translation>
    </message>
    <message>
        <source>Current page</source>
        <translation>現在のページ</translation>
    </message>
    <message>
        <source>Export scope:</source>
        <translation>書き出す範囲:</translation>
    </message>
    <message>
        <source>Use the .whiteboard file extension.</source>
        <translation>拡張子には .whiteboard を指定してください。</translation>
    </message>
    <message>
        <source>Whiteboard</source>
        <translation>ホワイトボード</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation>編集</translation>
    </message>
    <message>
        <source>File</source>
        <translation>ファイル</translation>
    </message>
    <message>
        <source>Save Image...</source>
        <translation>画像を保存...</translation>
    </message>
    <message>
        <source>Import Image...</source>
        <translation>画像を取り込み...</translation>
    </message>
    <message>
        <source>Import Image</source>
        <translation>画像を取り込み</translation>
    </message>
    <message>
        <source>Images (*.png *.jpg *.jpeg *.bmp *.svg)</source>
        <translation>画像 (*.png *.jpg *.jpeg *.bmp *.svg)</translation>
    </message>
    <message>
        <source>Could Not Import Image</source>
        <translation>画像を取り込めませんでした</translation>
    </message>
    <message>
        <source>Saved data could not be restored.
Editing and saving are stopped to protect the original file.</source>
        <translation>保存済みデータを復元できませんでした。
元ファイルを保護するため、編集と保存を停止しています。</translation>
    </message>
    <message>
        <source>The image could not be imported.
%1</source>
        <translation>画像を取り込めませんでした。
%1</translation>
    </message>
    <message>
        <source>PNG Images (*.png)</source>
        <translation>PNG 画像 (*.png)</translation>
    </message>
    <message>
        <source>SVG Images (*.svg)</source>
        <translation>SVG 画像 (*.svg)</translation>
    </message>
    <message>
        <source>whiteboard-page-%1</source>
        <translation>ホワイトボード-%1ページ</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation>画像を保存</translation>
    </message>
    <message>
        <source>Unsupported Image Format</source>
        <translation>未対応の画像形式</translation>
    </message>
    <message>
        <source>Use a .png or .svg file extension.</source>
        <translation>拡張子は .png または .svg を使用してください。</translation>
    </message>
    <message>
        <source>Could Not Save Image</source>
        <translation>画像を保存できませんでした</translation>
    </message>
    <message>
        <source>The image could not be saved.
%1</source>
        <translation>画像を保存できませんでした。
%1</translation>
    </message>
    <message>
        <source>Allow AI to apply %1 objects using mode &apos;%2&apos;?</source>
        <translation type="vanished">AI がモード「%2」で %1 個のオブジェクトを反映することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to update %1 objects on the current page?</source>
        <translation>AI が現在ページの %1 個のオブジェクトを更新することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to delete %1 objects from the current page?</source>
        <translation>AI が現在ページから %1 個のオブジェクトを削除することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to add %1, update %2, and delete %3 objects on the current page?</source>
        <translation>AI が現在ページで %1 個を追加、%2 個を更新、%3 個を削除することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to undo the most recent whiteboard change?</source>
        <translation>AI が直前のホワイトボード変更を元に戻すことを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to redo the most recently undone whiteboard change?</source>
        <translation>AI が直前に元へ戻したホワイトボード変更をやり直すことを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to add an empty page after the current page?</source>
        <translation>AI が現在ページの直後へ空ページを追加することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to delete the current page (%1)?</source>
        <translation>AI が現在のページ（%1）を削除することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to lock the current page?</source>
        <translation>AI が現在ページをロックすることを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to unlock the current page?</source>
        <translation>AI が現在ページのロックを解除することを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to save a %1 image to &apos;%2&apos; and overwrite an existing file?</source>
        <translation>AI が %1 画像を「%2」へ保存し、既存ファイルを上書きすることを許可しますか？</translation>
    </message>
    <message>
        <source>Allow AI to save a %1 image to &apos;%2&apos;?</source>
        <translation>AI が %1 画像を「%2」へ保存することを許可しますか？</translation>
    </message>
    <message>
        <source>This AI operation is not approved.</source>
        <translation>この AI 操作は許可されていません。</translation>
    </message>
    <message>
        <source>AI Diagram Request</source>
        <translation>AI 図作成リクエスト</translation>
    </message>
    <message>
        <source>The AI operation was declined by the user.</source>
        <translation>AI 操作はユーザーにより拒否されました。</translation>
    </message>
    <message>
        <source>Delete Page</source>
        <translation>ページ削除</translation>
    </message>
    <message>
        <source>Delete this page?</source>
        <translation>このページを削除しますか</translation>
    </message>
    <message>
        <source>Unsaved Changes</source>
        <translation>未保存の変更</translation>
    </message>
    <message>
        <source>Changes and settings have not been saved. Exiting without saving will lose them.</source>
        <translation>変更内容と設定が保存されていません。保存せず終了すると、今回の変更内容と設定は失われます。</translation>
    </message>
    <message>
        <source>Retry Saving</source>
        <translation>保存を再試行</translation>
    </message>
    <message>
        <source>Cancel Closing</source>
        <translation>終了を取り消す</translation>
    </message>
    <message>
        <source>Exit Without Saving</source>
        <translation>保存せず終了</translation>
    </message>
    <message>
        <source>Could Not Save Document</source>
        <translation>文書を保存できませんでした</translation>
    </message>
    <message>
        <source>None</source>
        <translation>なし</translation>
    </message>
    <message>
        <source>Triangle</source>
        <translation>三角</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>開き</translation>
    </message>
    <message>
        <source>Diamond</source>
        <translation>ひし形</translation>
    </message>
    <message>
        <source>Decrease</source>
        <translation>小さくする</translation>
    </message>
    <message>
        <source>Increase</source>
        <translation>大きくする</translation>
    </message>
    <message>
        <source>Reload Saved Data</source>
        <translation>保存済みデータを再読み込み</translation>
    </message>
    <message>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <source>Shortcuts</source>
        <translation>ショートカットキー</translation>
    </message>
    <message>
        <source>Tools</source>
        <translation>ツール</translation>
    </message>
    <message>
        <source>Select</source>
        <translation>選択</translation>
    </message>
    <message>
        <source>Reset Style</source>
        <translation>標準スタイルへ戻す</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>元に戻す</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>やり直し</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>コピー</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>ペースト</translation>
    </message>
    <message>
        <source>Quick Actions</source>
        <translation>クイック操作</translation>
    </message>
    <message>
        <source>Pen</source>
        <translation>ペン</translation>
    </message>
    <message>
        <source>Eraser</source>
        <translation>消しゴム</translation>
    </message>
    <message>
        <source>Line</source>
        <translation>直線</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <source>Rounded Rectangle</source>
        <translation>角丸矩形</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation>円</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation>楕円</translation>
    </message>
    <message>
        <source>Polyline</source>
        <translation>折れ線</translation>
    </message>
    <message>
        <source>Bezier</source>
        <translation>ベジェ曲線</translation>
    </message>
    <message>
        <source>Arc</source>
        <translation>円弧</translation>
    </message>
    <message>
        <source>Text</source>
        <translation>テキスト</translation>
    </message>
    <message>
        <source>Font</source>
        <translation>フォント</translation>
    </message>
    <message>
        <source>Delete Selected Object</source>
        <translation>選択要素を削除</translation>
    </message>
    <message>
        <source>Group</source>
        <translation>グループ化</translation>
    </message>
    <message>
        <source>Ungroup</source>
        <translation>グループ解除</translation>
    </message>
    <message>
        <source>Send Backward</source>
        <translation>背面へ</translation>
    </message>
    <message>
        <source>Bring Forward</source>
        <translation>前面へ</translation>
    </message>
    <message>
        <source>Send to Back</source>
        <translation>最背面へ</translation>
    </message>
    <message>
        <source>Bring to Front</source>
        <translation>最前面へ</translation>
    </message>
    <message>
        <source>Close Polyline or Bezier</source>
        <translation>折れ線/ベジェ曲線を閉じる</translation>
    </message>
    <message>
        <source>Open Polyline or Bezier</source>
        <translation>折れ線/ベジェ曲線を開く</translation>
    </message>
    <message>
        <source>Color</source>
        <translation>色</translation>
    </message>
    <message>
        <source>Fill</source>
        <translation>塗りつぶし</translation>
    </message>
    <message>
        <source>Scale Selected Shape</source>
        <translation>選択図形の倍率</translation>
    </message>
    <message>
        <source>Scale selected shape (%)</source>
        <translation>選択図形の倍率 (%)</translation>
    </message>
    <message>
        <source>Scale only the selected shape</source>
        <translation>選択図形だけを拡大縮小</translation>
    </message>
    <message>
        <source>Line </source>
        <translation>線 </translation>
    </message>
    <message>
        <source>Round </source>
        <translation>丸み </translation>
    </message>
    <message>
        <source>Solid</source>
        <translation>実線</translation>
    </message>
    <message>
        <source>Dotted</source>
        <translation>点線</translation>
    </message>
    <message>
        <source>Start: </source>
        <translation>始: </translation>
    </message>
    <message>
        <source>Start endpoint arrow</source>
        <translation>開始端点の矢印</translation>
    </message>
    <message>
        <source>End: </source>
        <translation>終: </translation>
    </message>
    <message>
        <source>End endpoint arrow</source>
        <translation>終了端点の矢印</translation>
    </message>
    <message>
        <source>Zoom Out</source>
        <translation>縮小</translation>
    </message>
    <message>
        <source>Zoom In</source>
        <translation>拡大</translation>
    </message>
    <message>
        <source>Previous Page</source>
        <translation>前ページ</translation>
    </message>
    <message>
        <source>Next Page</source>
        <translation>次ページ</translation>
    </message>
    <message>
        <source>Add Page</source>
        <translation>ページ追加</translation>
    </message>
    <message>
        <source>Lock Page</source>
        <translation>ページをロック</translation>
    </message>
    <message>
        <source>The import is applied, but saving is stopped. Do not repeat the import.</source>
        <translation>取り込みは反映済みですが、保存は停止しています。同じデータを再度取り込まないでください。</translation>
    </message>
    <message>
        <source>File: %1
Stage: %2
%3</source>
        <translation>ファイル: %1
失敗した処理: %2
%3</translation>
    </message>
    <message>
        <source>
Requested bytes: %1
Written bytes: %2</source>
        <translation>
保存予定のバイト数: %1
書き込んだバイト数: %2</translation>
    </message>
    <message>
        <source>Show Details</source>
        <translation>詳細を表示</translation>
    </message>
    <message>
        <source>Saving stopped - changes are unsaved</source>
        <translation>保存停止中 — 変更は未保存です</translation>
    </message>
    <message>
        <source>Saving available</source>
        <translation>保存可能</translation>
    </message>
    <message>
        <source>Restore failed - editing and saving are stopped</source>
        <translation>復元失敗 — 編集と保存を停止しています</translation>
    </message>
    <message>
        <source>Could Not Restore Document</source>
        <translation>文書を復元できませんでした</translation>
    </message>
    <message>
        <source>Saved data could not be restored. Editing and saving are stopped to protect the original file.</source>
        <translation>保存済みデータを復元できませんでした。元ファイルを保護するため、編集と保存を停止しています。</translation>
    </message>
    <message>
        <source>The document could not be saved. Changes remain on screen, but have not been saved to the file. Automatic saving has stopped.</source>
        <translation>保存できませんでした。画面上の変更は保持されていますが、今回の内容はファイルに保存できていません。自動保存を停止しました。</translation>
    </message>
    <message>
        <source>File: %1
%2</source>
        <translation>ファイル: %1
%2</translation>
    </message>
    <message>
        <source>Close Details</source>
        <translation>詳細を閉じる</translation>
    </message>
    <message>
        <source>Continue Editing</source>
        <translation>編集を続ける</translation>
    </message>
    <message>
        <source>Exit</source>
        <translation>終了</translation>
    </message>
    <message>
        <source>Saved.</source>
        <translation>保存しました。</translation>
    </message>
    <message>
        <source>Unlock Page</source>
        <translation>ページロック解除</translation>
    </message>
    <message>
        <source>&lt;table&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Select&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+1&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Pen&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+2&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Eraser&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+3&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Line&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+4&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Rectangle&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+5&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Circle&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+6&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Text&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+7&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Polyline&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+8&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Bezier&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+9&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Arc&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+0&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Delete selected objects&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Delete / Backspace&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Move selected objects by 1 px&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Arrow keys&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Group / Ungroup&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+G / Ctrl+Shift+G&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Move selected objects backward/forward one step&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+[ / Ctrl+]&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Move selected objects to back/front&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+[ / Ctrl+Shift+]&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Undo&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Z&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Redo&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Y / Ctrl+Shift+Z&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Zoom in/out&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Standard Zoom In / Zoom Out&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Previous / Next page&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Alt+Left / Alt+Right&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Add page&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+N&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Delete page&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+Backspace&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Start extending a polyline&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+endpoint click (Control+click on macOS)&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Close polyline/bezier&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Enter / Ctrl+Shift+C&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Open polyline/bezier&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+O&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Open a closed polyline at a vertex&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+vertex click&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Confirm text&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Enter&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;Cancel text editing&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Esc&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;</source>
        <translation>&lt;table&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;選択&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+1&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;ペン&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+2&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;消しゴム&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+3&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;直線&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+4&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;矩形&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+5&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;円&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+6&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;テキスト&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+7&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;折れ線&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+8&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;ベジェ曲線&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+9&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;円弧&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+0&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;選択要素を削除&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Delete / Backspace&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;選択要素を 1px 移動&lt;/b&gt;&lt;/td&gt;&lt;td&gt;矢印キー&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;グループ化 / 解除&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+G / Ctrl+Shift+G&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;選択要素を背面/前面へ 1 段移動&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+[ / Ctrl+]&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;選択要素を最背面/最前面へ移動&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+[ / Ctrl+Shift+]&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;元に戻す&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Z&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;やり直し&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Y / Ctrl+Shift+Z&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;ズームイン/アウト&lt;/b&gt;&lt;/td&gt;&lt;td&gt;標準 Zoom In / Zoom Out&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;前ページ / 次ページ&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Alt+Left / Alt+Right&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;ページ追加&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+N&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;ページ削除&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+Backspace&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;折れ線延長開始&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+端点クリック（macOS は Control+クリック）&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;折れ線/ベジェ曲線を閉じる&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Enter / Ctrl+Shift+C&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;折れ線/ベジェ曲線を開く&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+O&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;閉じた折れ線を頂点から開く&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Shift+頂点クリック&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;テキスト確定&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Ctrl+Enter&lt;/td&gt;&lt;/tr&gt;&lt;tr&gt;&lt;td&gt;&lt;b&gt;テキスト編集キャンセル&lt;/b&gt;&lt;/td&gt;&lt;td&gt;Esc&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;</translation>
    </message>
    <message>
        <source>Close Quick Actions</source>
        <translation>クイック操作を閉じる</translation>
    </message>
    <message>
        <source>%1 / %2</source>
        <translation>%1 / %2</translation>
    </message>
    <message>
        <source>Locked </source>
        <translation>ロック中 </translation>
    </message>
</context>
<context>
    <name>PersistentToolBar</name>
    <message>
        <source>More Tools</source>
        <translation>その他のツール</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>MCP Server</source>
        <translation>MCP サーバー</translation>
    </message>
    <message>
        <source>The local MCP HTTP server could not start: %1</source>
        <translation>ローカル MCP HTTP サーバーを開始できませんでした: %1</translation>
    </message>
    <message>
        <source>The save directory could not be created.</source>
        <translation>保存先のディレクトリを作成できませんでした。</translation>
    </message>
    <message>
        <source>The saved file is now missing. Restore it and reload, or preserve the original separately before restarting with a new document.</source>
        <translation>保存ファイルが見つからなくなりました。元の場所へ戻して再読み込みするか、原本を別の場所に保管したうえで再起動し、新しい文書を作成してください。</translation>
    </message>
    <message>
        <source>Choose a different file. The application&apos;s saved document cannot be replaced by an export.</source>
        <translation>別のファイルを選んでください。アプリの保存文書をエクスポートで置き換えることはできません。</translation>
    </message>
</context>
</TS>
