# Changelog

## 1.0.0 - 2026-09-02

### Added

- Added the first release version marker for WhiteboardApp.
- Added release notes and CMake version validation based on the `VERSION` file.

### Changed

- Use `VERSION` as the source for the CMake project version, application version, and MCP server information.
- Embedded the WhiteboardApp-specific MCP JSON-RPC / Streamable HTTP implementation in the application source tree.
- Removed the build-time and runtime dependency on an external qtmcpserver checkout.
